import Foundation
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers
let root=URL(fileURLWithPath:CommandLine.arguments[1])
var header="/* Build-time raster icons; RGB565, black transparent background. */\n"
for name in ["headphones","keyboard","battery0","battery1","battery2","battery3","batteryUnknown"] {
 let w=24,h=18
 let c=CGContext(data:nil,width:w,height:h,bitsPerComponent:8,bytesPerRow:w*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
 c.setFillColor(CGColor(red:0,green:0,blue:0,alpha:1));c.fill(CGRect(x:0,y:0,width:w,height:h))
 c.setFillColor(CGColor(red:0.4,green:0.8,blue:1,alpha:1));c.setStrokeColor(CGColor(red:0.4,green:0.8,blue:1,alpha:1));c.setLineWidth(2)
 if name=="headphones" {
  c.addArc(center:CGPoint(x:12,y:8),radius:8,startAngle:0,endAngle:.pi,clockwise:false);c.strokePath()
  c.fill(CGRect(x:3,y:2,width:4,height:8));c.fill(CGRect(x:17,y:2,width:4,height:8))
 } else if name.hasPrefix("battery") {
  c.setLineWidth(1.5);c.stroke(CGRect(x:1,y:4,width:19,height:10));c.fill(CGRect(x:21,y:7,width:2,height:4))
  let bars=Int(String(name.last!)) ?? 0
  for k in 0..<bars { c.fill(CGRect(x:3+k*5,y:6,width:3,height:6)) }
  if name=="batteryUnknown" { c.fill(CGRect(x:9,y:7,width:3,height:3)) }
 } else {
  for k in 0..<7 { c.fill(CGRect(x:1+k*3,y:2,width:2,height:14)) }
  c.setFillColor(CGColor(red:0,green:0,blue:0,alpha:1))
  for k in [0,1,3,4,5] { c.fill(CGRect(x:2+k*3,y:9,width:2,height:7)) }
 }
 let image=c.makeImage()!,raw=c.data!.assumingMemoryBound(to:UInt8.self)
 // Screen assets are stored top row first.
 var pixels:[String]=[]
 for y in 0..<h {
  var mask:UInt32=0
  for x in 0..<w {let i=((h-1-y)*w+x)*4;if Int(raw[i])+Int(raw[i+1])/2>20 {mask |= 1<<x} }
  pixels.append(String(format:"0x%06x",mask))
 }
 header += "static const uint32_t controller_icon_\(name)[18]={"+pixels.joined(separator:",")+"};\n"
 let dest=CGImageDestinationCreateWithURL(root.appendingPathComponent("build/icon-\(name).png") as CFURL,UTType.png.identifier as CFString,1,nil)!
 CGImageDestinationAddImage(dest,image,nil);CGImageDestinationFinalize(dest)
}
try header.write(to:root.appendingPathComponent("source/app/controller_status_icons.h"),atomically:true,encoding:.utf8)
