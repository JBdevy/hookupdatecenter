// Compile the existing CatLive cat into a flash bitmap for the two-second startup.
import Foundation
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers
let root=URL(fileURLWithPath:CommandLine.arguments[1])
let source=CGImageSourceCreateWithURL(root.appendingPathComponent("assets/CatLiveLogo.png") as CFURL,nil)!
let original=CGImageSourceCreateImageAtIndex(source,0,nil)!
let cat=original.cropping(to:CGRect(x:0,y:0,width:1240,height:810))!
let w=128,h=88
let ctx=CGContext(data:nil,width:w,height:h,bitsPerComponent:8,bytesPerRow:w*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
ctx.setFillColor(CGColor(red:0,green:0,blue:0,alpha:1));ctx.fill(CGRect(x:0,y:0,width:w,height:h))
ctx.interpolationQuality = .high
ctx.draw(cat,in:CGRect(x:0,y:2,width:128,height:84))
let raw=ctx.data!.assumingMemoryBound(to:UInt8.self)
var encoded:[UInt8]=[],offsets:[Int]=[]
let pixels=(0..<(w*h)).map { i -> UInt16 in
 let r=UInt16(raw[i*4]),g=UInt16(raw[i*4+1]),b=UInt16(raw[i*4+2])
 return (r>>3)<<11 | (g>>2)<<5 | b>>3
}
for y in 0..<h {
 offsets.append(encoded.count)
 var x=0
 while x<w {
  let value=pixels[y*w+x]
  var end=x+1
  while end<w && pixels[y*w+end]==value {end+=1}
  if end-x>=3 {
   encoded += [UInt8(128+end-x-1),UInt8(value>>8),UInt8(value&255)]
   x=end
  } else {
   let start=x
   x=end
   while x<w && x-start<128 {
    var next=x+1
    while next<w && pixels[y*w+next]==pixels[y*w+x] {next+=1}
    if next-x>=3 {break}
    x=next
   }
   encoded.append(UInt8(x-start-1))
   for col in start..<x {let p=pixels[y*w+col];encoded += [UInt8(p>>8),UInt8(p&255)]}
  }
 }
}
let lines=stride(from:0,to:encoded.count,by:24).map{encoded[$0..<min($0+24,encoded.count)].map{String($0)}.joined(separator:",")}.joined(separator:",\n")
let header="/* Generated lossless row RLE by tools/compile-boot-logo.swift. */\nstatic const uint16_t controller_boot_rows[88]={"+offsets.map{String($0)}.joined(separator:",")+"};\nstatic const uint8_t controller_boot_logo[]={\n"+lines+"\n};\n"
try header.write(to:root.appendingPathComponent("source/app/controller_boot_logo.h"),atomically:true,encoding:.utf8)
print("Boot logo: \(encoded.count+offsets.count*2) bytes in flash")
let dest=CGImageDestinationCreateWithURL(root.appendingPathComponent("build/controller-boot-logo.png") as CFURL,UTType.png.identifier as CFString,1,nil)!
CGImageDestinationAddImage(dest,ctx.makeImage()!,nil);CGImageDestinationFinalize(dest)

