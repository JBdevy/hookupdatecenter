// Compile the existing CatLive artwork into a flash-resident RGB565 UI strip.
import Foundation
import CoreGraphics
import CoreText
import ImageIO
import UniformTypeIdentifiers
let root = URL(fileURLWithPath: CommandLine.arguments[1])
let source = CGImageSourceCreateWithURL(root.appendingPathComponent("assets/CatLiveLogo.png") as CFURL,nil)!
let image = CGImageSourceCreateImageAtIndex(source,0,nil)!
let w=240, h=56
let context=CGContext(data:nil,width:w,height:h,bitsPerComponent:8,bytesPerRow:w*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
context.setFillColor(CGColor(red:0,green:0,blue:0,alpha:1));context.fill(CGRect(x:0,y:0,width:w,height:h))
context.interpolationQuality = .high
// Two views of the original logo atlas; no replacement artwork.
let cat=image.cropping(to:CGRect(x:0,y:0,width:1240,height:810))!
let word=image.cropping(to:CGRect(x:160,y:825,width:960,height:200))!
context.draw(cat,in:CGRect(x:4,y:6,width:76,height:50))
context.draw(word,in:CGRect(x:90,y:19,width:145,height:30))
let font=CTFontCreateWithName("Helvetica" as CFString,9,nil)
let caption=NSAttributedString(string:"Daw Integration",attributes:[NSAttributedString.Key(kCTFontAttributeName as String):font,NSAttributedString.Key(kCTForegroundColorAttributeName as String):CGColor(red:0.86,green:0.86,blue:0.86,alpha:1)])
let line=CTLineCreateWithAttributedString(caption)
let captionWidth=CTLineGetTypographicBounds(line,nil,nil,nil)
context.textPosition=CGPoint(x:90+(145-captionWidth)/2,y:6)
CTLineDraw(line,context)
let raw=context.data!.assumingMemoryBound(to:UInt8.self)
var pixels:[String]=[]
for i in 0..<(w*h) { let r=UInt16(raw[i*4]),g=UInt16(raw[i*4+1]),b=UInt16(raw[i*4+2]);pixels.append(String(format:"0x%04x",(r>>3)<<11 | (g>>2)<<5 | b>>3)) }
let lines=stride(from:0,to:pixels.count,by:16).map{pixels[$0..<min($0+16,pixels.count)].joined(separator:",")}.joined(separator:",\n")
try ("/* Generated from CatLiveLogo.png by tools/compile-brand.swift. */\nstatic const uint16_t controller_brand[240*56] = {\n"+lines+"\n};\n").write(to:root.appendingPathComponent("source/app/controller_brand.h"),atomically:true,encoding:.utf8)
let preview=CGImageDestinationCreateWithURL(root.appendingPathComponent("build/controller-header.png") as CFURL,UTType.png.identifier as CFString,1,nil)!
CGImageDestinationAddImage(preview,context.makeImage()!,nil);CGImageDestinationFinalize(preview)
print("Compiled fixed CatLive header: 26,880 bytes in flash")
