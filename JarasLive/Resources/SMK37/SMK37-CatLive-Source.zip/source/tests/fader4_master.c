/* Regression test for the physical F4 -> internal master customisation. */
#include "smk37_controls.h"
#include "instrument.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static unsigned volumes[8], track_edits, midi_events, midi_faders;
static unsigned last_track, last_status;
void groove_midi_poll(void) {}
int groove_midi_local(const uint8_t *m, size_t n)
{ assert(n); ++midi_events; last_status=m[0]; return 0; }
int fm1_midi_post(const uint8_t *m, size_t n)
{ return groove_midi_local(m,n); }
unsigned groove_midi_input_channel(unsigned t) { return t; }
unsigned groove_midi_setting(unsigned t,unsigned p) { (void)t; (void)p; return 1; }
void groove_get_view(unsigned t,unsigned s,struct groove_view *v)
{ (void)s; assert(t<8); memset(v,0,sizeof *v); v->volume=volumes[t]; }
void groove_control_edit(unsigned t,int program,int volume,int cutoff)
{ assert(!program && !cutoff && t<8); volumes[t]+=volume; ++track_edits; last_track=t; }
void groove_midi_fader(unsigned t,unsigned v)
{ assert(t<8 && v<128); ++midi_faders; last_track=t; }
unsigned groove_track_role(unsigned t) { (void)t; return 0; }
unsigned groove_source_type(unsigned t) { (void)t; return 0; }
unsigned groove_pad_count(unsigned t) { (void)t; return 16; }
unsigned groove_pad_note(unsigned t,unsigned p) { (void)t; return 36+p; }
unsigned smk37_performance_track(unsigned p) { return p ? 7 : 0; }
int smk37_performance_octave(unsigned p) { (void)p; return 0; }
void smk37_screen_note(unsigned t,unsigned n) { (void)t; (void)n; }
int smk37_screen_pad(unsigned p,unsigned v,unsigned s) { (void)p; (void)v; (void)s; return 0; }
unsigned smk37_screen_pad_key(unsigned p) { (void)p; return 255; }
void smk37_screen_pad_mode(unsigned s,unsigned i) { (void)s; (void)i; }
void smk37_screen_page(unsigned p) { (void)p; }
void smk37_screen_shortcut(unsigned p) { (void)p; }
unsigned smk37_screen_track(void) { return 0; }

static void f4(int value) { smk37_control_event(SMK37_FADER,3,value); }
static void change_bank(void)
{
    smk37_control_event(SMK37_BUTTON,1,1);
    smk37_control_event(SMK37_BUTTON,1,0);
}

int main(void)
{
    for(unsigned i=0;i<8;++i)volumes[i]=64;
    smk37_controls_reset();
    /* The first hardware sample must honour a lowered physical master. */
    f4(0); assert(smk37_master_level()==0);
    for(unsigned bank=0;bank<2;++bank) {
        assert(smk37_fader_bank()==bank);
        unsigned previous=0;
        for(int value=0;value<128;++value) {
            f4(value);
            unsigned level=smk37_master_level();
            assert(level<=1023 && (value==0 || level>previous));
            struct fm1_controls state; smk37_controls_snapshot(&state);
            assert(state.knob==level);
            previous=level;
        }
        assert(smk37_master_level()==1023);
        f4(64); assert(smk37_master_level()>500 && smk37_master_level()<525);
        f4(-1); assert(smk37_master_level()==0);
        f4(1000); assert(smk37_master_level()==1023);
        unsigned before=smk37_master_level(); change_bank();
        assert(smk37_master_level()==before && !(smk37_pickup_mask()&8));
    }
    assert(!track_edits && !midi_faders && !midi_events);
    for(unsigned i=0;i<8;++i)assert(volumes[i]==64);

    /* The dedicated master encoder remains usable; F4 takes over on motion. */
    f4(0); smk37_control_event(SMK37_ENCODER,7,8);
    assert(smk37_master_level()>0);
    f4(0); assert(smk37_master_level()==0);
    smk37_master_set(512); f4(127); assert(smk37_master_level()==1023);

    /* F1-F3 retain track volumes and pickup in both banks, without master edits. */
    for(unsigned bank=0;bank<2;++bank) {
        assert(smk37_fader_bank()==bank);
        for(unsigned id=0;id<3;++id) {
            smk37_control_event(SMK37_FADER,id,64);
            smk37_control_event(SMK37_FADER,id,90);
            assert(volumes[4*bank+id]==90 && last_track==4*bank+id);
            assert(smk37_master_level()==1023);
        }
        change_bank();
    }
    assert(track_edits==6 && midi_faders==6 && !midi_events);
    assert(volumes[3]==64 && volumes[7]==64);
    /* The adjacent pitch/modulation ADC IDs keep their original MIDI routes. */
    smk37_control_event(SMK37_FADER,4,75); assert(last_status==0xe0);
    smk37_control_event(SMK37_FADER,5,80); assert(last_status==0xb0);
    assert(smk37_master_level()==1023);
    puts("FADER4_INTERNAL_MASTER_OK: startup, range, banks, encoder, other faders and wheels");
    return 0;
}
