/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * CatLive private controller protocol, version 1. All bytes between F0/F7
 * are 7-bit; sum including checksum is zero modulo 128. No Flash from RX. */
#include "controller.h"
#ifndef FM1_HOST_TEST
#include "instrument.h"
#endif
#include <string.h>
#ifdef FM1_HOST_TEST
#include <stdatomic.h>
#define WORD _Atomic(unsigned)
#else
#define WORD volatile unsigned
#endif
#ifndef FM1_HOST_TEST
/* Keep the SDK's public BLE control entry points in a menu-free image. The
 * SDK integrity/audit scripts stay byte-for-byte original; no checks bypassed. */
static void (*volatile sdk_ble_api[])(void)={
    (void (*)(void))fm1_ble_scan,(void (*)(void))fm1_ble_connect,
    (void (*)(void))fm1_ble_disconnect,(void (*)(void))fm1_ble_get_device,
    (void (*)(void))fm1_ble_forget_bonds,(void (*)(void))fm1_bluetooth_get_status,
    (void (*)(void))groove_tuning_capture,(void (*)(void))groove_tuning_apply,
    (void (*)(void))groove_project_apply_edit
};
#endif
static const uint8_t signature[6]={0xf0,0x7d,'C','L','S',1};
enum { QUEUE=32, NAME=65, MESSAGE=96 };
static struct { uint8_t bytes[MESSAGE],length,source; } incoming[QUEUE];
static WORD incoming_read,incoming_write;
static char preset_names[6][NAME],pad_names[6][16][NAME];
static uint32_t preset_colors[6],pad_colors[6][16],host_at,pad_at;
static unsigned revision,host_port,host_live,reply_pending,last_pad,pad_overlay,last_serial;
static uint16_t active_pads;
static char action_title[NAME],loop_title[NAME];
static uint32_t loop_color;
static uint32_t action_color,action_at;
static unsigned action_overlay,transport_flags,blink_phase,mode_overlay;
static uint32_t mode_at,waiting_at,controller_boot_at;
static unsigned controller_boot_running;
void controller_boot_start(void)
{ controller_boot_at=waiting_at=fm1_millis();controller_boot_running=1; }
unsigned controller_boot_progress(void)
{
    if(!controller_boot_running)return 200;
    uint32_t elapsed=fm1_millis()-controller_boot_at;
    if(elapsed>=2000U){controller_boot_running=0;return 200;}
    return elapsed/10U;
}
static unsigned fade_active,fade_tenths,fade_fraction;
static char navigation_rows[5][25];
static unsigned navigation_kind,play_progress,play_elapsed,play_duration;
static uint32_t navigation_at;
static void barrier(void) {
#ifndef FM1_HOST_TEST
    __asm__ volatile("csync" ::: "memory");
#endif
}
static unsigned packet(uint8_t *out,unsigned command,const uint8_t *data,unsigned length)
{
    memcpy(out,signature,6);out[6]=(uint8_t)command;
    if(length)memcpy(out+7,data,length);
    unsigned sum=0;for(unsigned i=1;i<7+length;++i)sum+=out[i];
    out[7+length]=(uint8_t)((128-(sum&127))&127);out[8+length]=0xf7;
    return length+9;
}
static uint32_t color(const uint8_t *n)
{ uint32_t rgb=0;for(unsigned i=0;i<6;++i)rgb=(rgb<<4)|n[i];return rgb; }
static int metadata(const uint8_t *data,unsigned length)
{
    if(length<6 || length>6+NAME-1)return 0;
    for(unsigned i=0;i<6;++i)if(data[i]>15)return 0;
    for(unsigned i=6;i<length;++i)if(data[i]<32 || data[i]>126)return 0;
    return 1;
}
void controller_link_reset(void)
{
#ifndef FM1_HOST_TEST
    for(unsigned i=0;i<sizeof sdk_ble_api/sizeof *sdk_ble_api;++i)(void)sdk_ble_api[i];
#endif
    waiting_at=fm1_millis();controller_boot_running=0;
    fade_active=fade_tenths=fade_fraction=0;navigation_kind=play_progress=play_elapsed=play_duration=0;
    incoming_read=incoming_write=0;revision=host_live=reply_pending=pad_overlay=active_pads=0;
    last_serial=255;last_pad=0;action_overlay=transport_flags=blink_phase=mode_overlay=0;loop_title[0]=0;loop_color=0xffb347;
    for(unsigned p=0;p<6;++p) {
        memcpy(preset_names[p],"PRESET 1",9);preset_names[p][7]=(char)('1'+p);preset_colors[p]=0xeeeeee;
        for(unsigned n=0;n<16;++n) {
            memcpy(pad_names[p][n],"PAD 00",7);pad_names[p][n][4]=(char)('0'+(n+1)/10);pad_names[p][n][5]=(char)('0'+(n+1)%10);
            pad_colors[p][n]=0x246044;
        }
    }
}
int controller_link_receive(const uint8_t *message,unsigned length,unsigned source)
{
    if(!message || length<6 || memcmp(message,signature,6))return 0;
    if(source>=3 || length<9 || length>MESSAGE || message[length-1]!=0xf7)return 1;
    unsigned sum=0;for(unsigned i=1;i<length-1;++i){if(message[i]>127)return 1;sum+=message[i];}
    if(sum&127)return 1;
    unsigned w=incoming_write;if(w-incoming_read>=QUEUE)return 1;
    memcpy(incoming[w&(QUEUE-1)].bytes,message,length);
    incoming[w&(QUEUE-1)].length=(uint8_t)length;incoming[w&(QUEUE-1)].source=(uint8_t)source;
    barrier();incoming_write=w+1;fm1_control_request();return 1;
}
void controller_link_select(unsigned preset,unsigned channel)
{
    uint8_t bytes[16],data[2]={(uint8_t)preset,(uint8_t)channel};
    unsigned length=packet(bytes,0x20,data,2);controller_output_sysex(bytes,length);
    pad_overlay=0;++revision;
}
unsigned controller_link_active(void) { return host_live; }
static void relative_step(unsigned command,int step)
{
    if(!step)return;
    if(step>63)step=63;if(step< -63)step= -63;
    uint8_t bytes[16],data=(uint8_t)(step+64);
    controller_output_sysex(bytes,packet(bytes,command,&data,1));
}
void controller_link_preview_step(int step) { relative_step(0x23,step); }
void controller_link_playlist_step(int step) { relative_step(0x24,step); }
void controller_link_fadeout(unsigned active)
{
    uint8_t bytes[16],data=(uint8_t)!!active;
    controller_output_sysex(bytes,packet(bytes,0x25,&data,1));
}
void controller_link_mode_changed(void)
{
    uint8_t bytes[16],data[3]={(uint8_t)(controller_mode()==3?2:controller_mode()),(uint8_t)controller_preset(),(uint8_t)controller_channel()};
    unsigned length=packet(bytes,0x22,data,3);controller_output_sysex(bytes,length);
    navigation_kind=0;pad_overlay=0;active_pads=0;action_overlay=0;mode_overlay=controller_mode()==0;mode_at=fm1_millis();++revision;
}
void controller_link_poll(void)
{
    uint32_t now=fm1_millis();
    if(host_live && now-host_at>=3500U) {waiting_at=now;host_live=0;fade_active=0;navigation_kind=0;play_duration=0;active_pads=0;transport_flags=action_overlay=reply_pending=0;++revision;}
    if(navigation_kind && now-navigation_at>=2000U) {navigation_kind=0;++revision;}
    if(pad_overlay && now-pad_at>=2000U) {pad_overlay=0;++revision;}
    if(mode_overlay && now-mode_at>=2000U) {mode_overlay=0;++revision;}
    if(action_overlay && now-action_at>=2000U) {action_overlay=0;++revision;}
    unsigned phase=transport_flags&6 ? ((now/500U)&1U) : 0;
    if(blink_phase!=phase) {blink_phase=phase;++revision;}
    for(unsigned work=0;work<8 && incoming_read!=incoming_write;++work) {
        unsigned r=incoming_read;barrier();
        uint8_t message[MESSAGE];unsigned length=incoming[r&(QUEUE-1)].length,source=incoming[r&(QUEUE-1)].source;
        memcpy(message,incoming[r&(QUEUE-1)].bytes,length);barrier();incoming_read=r+1;
        const uint8_t *data=message+7;unsigned n=length-9,cmd=message[6];
        if(cmd==1 && !n) {
            if(host_live && host_port!=source)continue;
            if(!host_live)++revision;
            host_port=source;host_at=now;host_live=reply_pending=1;
        } else if(!host_live || source!=host_port)continue;
        else if(cmd==2 && !n) {waiting_at=now;host_live=0;fade_active=0;navigation_kind=0;play_duration=0;active_pads=0;pad_overlay=transport_flags=action_overlay=reply_pending=0;++revision;}
        else if(cmd==0x10 && n>=7 && data[0]<6 && metadata(data+1,n-1)) {
            unsigned p=data[0];preset_colors[p]=color(data+1);
            memcpy(preset_names[p],data+7,n-7);preset_names[p][n-7]=0;++revision;
        } else if(cmd==0x11 && n>=8 && data[0]<6 && data[1]<16 && metadata(data+2,n-2)) {
            unsigned p=data[0],pad=data[1];pad_colors[p][pad]=color(data+2);
            memcpy(pad_names[p][pad],data+8,n-8);pad_names[p][pad][n-8]=0;++revision;
        } else if(cmd==0x13 && n>6 && metadata(data,n)) {
            navigation_kind=0;action_color=color(data);memcpy(action_title,data+6,n-6);action_title[n-6]=0;
            action_at=now;action_overlay=1;++revision;
        } else if(cmd==0x15 && n>=6 && metadata(data,n)) {
            loop_color=color(data);memcpy(loop_title,data+6,n-6);loop_title[n-6]=0;++revision;
        } else if(cmd==0x14 && n==1 && data[0]<128) {
            if(transport_flags!=data[0]) {transport_flags=data[0];++revision;}
        } else if(cmd==0x16 && n==3 && data[0]<2 && data[1]<=50) {
            if(fade_active!=data[0] || fade_tenths!=data[1] || fade_fraction!=data[2]) {
                fade_active=data[0];fade_tenths=data[1];fade_fraction=data[2];++revision;
            }
        } else if(cmd==0x17 && n>=6 && data[0]>=1 && data[0]<=3) {
            // Validate the complete viewport before publishing any row.
            char rows[5][25]={{0}};unsigned at=1,valid=1;
            for(unsigned row=0;row<5 && valid;++row) {
                if(at>=n){valid=0;break;}
                unsigned size=data[at++],limit=row==2?24:14;
                if(size>limit || size>n-at){valid=0;break;}
                for(unsigned i=0;i<size;++i)if(data[at+i]<32 || data[at+i]>126)valid=0;
                if(valid)memcpy(rows[row],data+at,size);at+=size;
            }
            if(valid && at==n) {
                memcpy(navigation_rows,rows,sizeof rows);navigation_kind=data[0];navigation_at=now;
                action_overlay=0;++revision;
            }
        } else if(cmd==0x18 && n==8 && (data[0]|(data[1]<<7))<=200) {
            unsigned progress=data[0]|(data[1]<<7),elapsed=data[2]|(data[3]<<7)|(data[4]<<14),duration=data[5]|(data[6]<<7)|(data[7]<<14);
            if(elapsed<=duration && (progress!=play_progress || elapsed!=play_elapsed || duration!=play_duration)) {
                play_progress=progress;play_elapsed=elapsed;play_duration=duration;++revision;
            }
        } else if(cmd==0x12 && n==6 && data[0]<6 && (data[1]<16 || data[1]==127) && data[5]<4) {
            if(controller_preset()!=data[0]) {controller_select_remote(data[0]);pad_overlay=0;++revision;}
            active_pads=(uint16_t)(data[3]|(data[4]<<7)|(data[5]<<14));
            if(last_serial!=data[2]) {
                last_serial=data[2];pad_overlay=data[1]<16;
                if(pad_overlay){last_pad=data[1];pad_at=now;}++revision;
            }
        }
    }
    if(reply_pending) {
        uint8_t bytes[16],data[3]={(uint8_t)controller_preset(),(uint8_t)controller_channel(),(uint8_t)(controller_mode()==3?2:controller_mode())};
        unsigned length=packet(bytes,0x41,data,3);
        if(!fm1_midi_send_port(host_port,bytes,length))reply_pending=0;
    }
}
unsigned controller_link_revision(void) { return revision & 0x7fffU; }
const char *controller_link_title(void)
{
    if(controller_mode()==3)return "AUDIO RECEIVE";
    if(!host_live)return "AGUARDANDO CONEXAO";
    if(mode_overlay)return "PADS FX CONTROLLER";
    if(controller_mode()==2)return "DAW CONTROLLER FREE";
    if(action_overlay)return action_title;
    if(controller_mode()) {
        if(transport_flags&1)return "PAUSE";
        if(transport_flags&2)return "REC";
        if((transport_flags&4) && loop_title[0])return loop_title;
        if((transport_flags&32) && loop_title[0])return loop_title;
        return "DAW CONTROLLER";
    }
    return pad_overlay?pad_names[controller_preset()][last_pad]:preset_names[controller_preset()];
}
uint32_t controller_link_title_color(void)
{
    if(controller_mode()==3)return 0x55cfff;
    if(!host_live || mode_overlay)return 0xeeeeee;
    if(controller_mode()==2)return 0xeeeeee;
    if(action_overlay)return action_color?action_color:0xeeeeee;
    if(controller_mode()) {
        if(transport_flags&1)return 0xffd845;
        if(transport_flags&2)return blink_phase?0:0xff2020;
        if((transport_flags&4) && loop_title[0])return loop_color?loop_color:0xffb347;
        return 0x55cfff;
    }
    uint32_t rgb=pad_overlay?pad_colors[controller_preset()][last_pad]:preset_colors[controller_preset()];
    return rgb?rgb:0xeeeeee;
}
uint32_t controller_link_pad_color(unsigned pad,unsigned held)
{
    if(pad>=16)return 0;
    unsigned starting=controller_boot_progress()<200;
    if(!starting && controller_mode()==3)return 0x060606;
    if(starting || !host_live) {
        /* Physical perimeter: top left -> top right -> bottom right -> bottom
         * left. One green lap, one purple lap; never send MIDI for this effect. */
        unsigned step=((uint32_t)(fm1_millis()-(starting?controller_boot_at:waiting_at))/40U)%32U;
        unsigned position=step&15U;
        unsigned selected=position<8U?position:23U-position;
        return pad==selected?(step<16U?0x0b331c:0x26073f):0;
    }
    uint32_t rgb=pad_colors[controller_preset()][pad];
    unsigned active=!controller_mode() && (active_pads&(1U<<pad));
    if(controller_mode()==2)rgb=0x626262;
    if(controller_mode()==1) {
        static const uint32_t daw[16]={0xff2020,0,0,0x9b59b6,0x9b59b6,0xff8800,0xff8800,0,
            0,0,0,0x409cff,0x409cff,0x2ecc71,0x2ecc71,0};
        rgb=daw[pad];
        if(pad==0 && (transport_flags&2)) {active=1;if(blink_phase)return 0;}
        if(pad==2) {rgb=(transport_flags&16)?0xffffff:0;active=!!rgb;}
        if(pad==7) {rgb=(transport_flags&8)?0x2ecc71:0;active=!!rgb;}
        if(pad==8) {rgb=(transport_flags&1)?0:(transport_flags&32)?0xff2020:0x2ecc71;active=1;}
        if(pad==9) {rgb=(transport_flags&1)?0xffd845:0;active=!!rgb;}
        if(pad==10) {if((transport_flags&4)&&blink_phase)return 0;rgb=(transport_flags&4)?0xffd845:0;active=!!rgb;}
        if(pad==15) {rgb=(transport_flags&64)?0x981fff:0;active=!!rgb;}
    }
    /* Preserve hue. DAW navigation brightens while physically held;
       Pads FX brightens only when playback is confirmed by CatLive. */
    /* Unassigned/inactive controls remain visible in dim neutral white.
       The off phase of blinking REC/Repeat is kept dark above. */
    if(!rgb)return 0x060606;
    const unsigned divisor=controller_mode()==1 && controller_navigation_pad(pad) && held?2:
        controller_mode()==0&&!active?12:4;
    return (((rgb>>16)&255)/divisor<<16)|(((rgb>>8)&255)/divisor<<8)|((rgb&255)/divisor);
}

unsigned controller_link_navigation(void) { return host_live && controller_mode()==1 && !controller_channel_visible()?navigation_kind:0; }
const char *controller_link_row(unsigned row) { return row<5?navigation_rows[row]:""; }
unsigned controller_link_playback(void) { return host_live && controller_mode()==1 && (transport_flags&33) && play_duration; }
unsigned controller_link_progress(void) { return play_progress; }
unsigned controller_link_elapsed(void) { return play_elapsed; }
unsigned controller_link_duration(void) { return play_duration; }
unsigned controller_link_fading(void) { return host_live && controller_mode()==1 && (transport_flags&32) && fade_active; }
unsigned controller_link_fade_tenths(void) { return fade_tenths; }
unsigned controller_link_fade_fraction(void) { return fade_fraction; }
unsigned controller_link_recording(void) { return controller_mode()==1 && (transport_flags&2); }
unsigned controller_link_looping(void) { return controller_mode()==1 && (transport_flags&4); }
unsigned controller_link_blink(void) { return !blink_phase; }
/* Four centered lines, 19 glyphs each. Prefer word boundaries; split a word
 * only when it alone exceeds the display width. No scrolling while reading. */
unsigned controller_wrap_title(const char *title,char lines[4][20])
{
    unsigned count=0;
    while(*title && count<4) {
        while(*title==' ')++title;
        if(!*title)break;
        unsigned n=0;while(title[n] && n<19)++n;
        if(title[n] && title[n]!=' ') {
            unsigned boundary=n;while(boundary && title[boundary]!=' ')--boundary;
            if(boundary)n=boundary;
        }
        memcpy(lines[count],title,n);lines[count][n]=0;
        title+=n;++count;
    }
    return count;
}
