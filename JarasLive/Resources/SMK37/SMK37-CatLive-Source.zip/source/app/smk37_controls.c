/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * CatLive controller edition. K1 selects one of six presets, K2 selects
 * its channel. Physical keys retain note ownership across either change. */
#include "smk37_controls.h"
#include "controller.h"
#include "audio_output.h"
#include <string.h>
struct key_owner { uint8_t note, channel; };
static struct key_owner keys[37];
static uint8_t pad_channels[16],button_channels[12],channels[CONTROLLER_PRESETS];
static unsigned bluetooth_page;
unsigned controller_bluetooth_page(void){return bluetooth_page;}
static unsigned extra_button(unsigned id)
{ static const uint8_t index[18]={0,1,255,255,255,255,2,3,4,5,6,255,255,7,8,9,10,11};return index[id]; }
static uint8_t knobs[CONTROLLER_PRESETS][8], faders[4], fader_valid;
static int preview_steps, playlist_steps;
static uint8_t fade_zone;
static uint8_t daw_mode;
static unsigned receiver_volume;
unsigned controller_audio_volume(void) { return receiver_volume; }
static uint8_t selected, pedal_down, wheel_values[2], wheel_valid;
static uint16_t pedal_channels, wheel_channels[2];
static uint32_t buttons, channel_at;
static unsigned channel_overlay;
static uint16_t repeat_held,repeat_started;
static uint32_t repeat_at[16];
static int octave;
static unsigned bounded(int value,unsigned high)
{ return value<0?0:(unsigned)value>high?high:(unsigned)value; }
static void cc(unsigned ch,unsigned number,unsigned value)
{ controller_output_send(0xb0|ch,number,value); }
unsigned controller_mode(void) { return daw_mode; }
unsigned controller_preset(void) { return selected; }
void controller_select_remote(unsigned preset)
{ if(preset<CONTROLLER_PRESETS) { selected=(uint8_t)preset;channel_overlay=0; } }
unsigned controller_channel(void) { return channels[selected]; }
unsigned controller_channel_visible(void)
{
    if (channel_overlay && fm1_millis()-channel_at>=2000U) channel_overlay=0;
    return channel_overlay;
}
void controller_preferences_read(uint8_t data[4])
{
    for (unsigned i=0;i<3;++i) data[i]=(uint8_t)(channels[2*i]|(channels[2*i+1]<<4));
    data[3]=(uint8_t)(0xc0|(daw_mode<<3)|selected);
}
void controller_preferences_apply(const uint8_t data[4])
{
    if (((data[3]&0xf0)!=0xa0 && (data[3]&0xe0)!=0xc0) || (data[3]&7)>=CONTROLLER_PRESETS) return;
    unsigned mode=(data[3]&0xe0)==0xc0?(data[3]>>3)&3:(data[3]>>3)&1;
    if(mode>3)return;
    for (unsigned i=0;i<6;++i) channels[i]=(data[i/2]>>(4*(i&1)))&15;
    selected=data[3]&7;daw_mode=(uint8_t)mode;preview_steps=playlist_steps=0;fade_zone=0;
    fm1_output_receiver(daw_mode==3,receiver_volume);
    if(daw_mode==3)controller_audio_enable();
}
void groove_midi_panel_reset(void) { /* Synth router does not own controller notes. */ }
void groove_midi_panel_track_reset(unsigned track) { (void)track; }
void smk37_controls_reset(void)
{
    memset(keys,255,sizeof keys); memset(pad_channels,255,sizeof pad_channels);
    memset(button_channels,255,sizeof button_channels);bluetooth_page=0;
    memset(channels,0,sizeof channels); memset(knobs,64,sizeof knobs);
    memset(faders,0,sizeof faders); memset(wheel_channels,0,sizeof wheel_channels);
    daw_mode=selected=fader_valid=pedal_down=wheel_valid=0;
    receiver_volume=0;fm1_output_receiver(0,0);
    buttons=pedal_channels=channel_overlay=0; octave=0;preview_steps=playlist_steps=0;fade_zone=0;
    wheel_values[0]=64;wheel_values[1]=0;
    repeat_held=repeat_started=0;
    controller_output_reset();controller_link_reset();
}
void smk37_controls_panic(void)
{
    repeat_held=repeat_started=0;
    controller_output_panic();controller_output_poll();
    memset(keys,255,sizeof keys);memset(pad_channels,255,sizeof pad_channels);
    memset(button_channels,255,sizeof button_channels);
    pedal_down=0;pedal_channels=0;wheel_channels[0]=wheel_channels[1]=0;
    buttons=0;
}
/* Accumulate physical encoder steps. Reversing direction drops the old
 * remainder, so the next group is always four steps in the new direction. */
static int page_step(int *pending,int delta)
{
    if((*pending<0 && delta>0)||(*pending>0 && delta<0))*pending=0;
    if(delta>252)delta=252;if(delta< -252)delta= -252;
    *pending+=delta;int step=*pending/4;*pending-=step*4;return step;
}
static void key_release(unsigned id)
{
    if (keys[id].note>=128) return;
    unsigned note=keys[id].note,ch=keys[id].channel;
    keys[id].note=255;
    for (unsigned i=0;i<37;++i)
        if (keys[i].note==note && keys[i].channel==ch) return;
    controller_output_send(0x80|ch,note,0);
}
void smk37_control_event(unsigned kind,unsigned id,int value)
{
    unsigned ch=controller_channel();
    /* Receiver mode never triggers mapped pads or the internal instrument.
     * Keep PATCH+arrows and Bluetooth settings available; F4 is local master. */
    if(daw_mode==3 && kind!=SMK37_BUTTON && !(bluetooth_page && kind==SMK37_ENCODER)) {
        if(kind==SMK37_FADER && id==3) {
            receiver_volume=bounded(value,127);faders[3]=(uint8_t)receiver_volume;fader_valid|=8;
            fm1_output_receiver(1,receiver_volume);
        }
        return;
    }
    if (kind==SMK37_ENCODER && id<8) {
        if (!value) return;
        if(bluetooth_page) {
            if(id==3)controller_bluetooth_set(value>0);
            if(id==4) {
                unsigned next=bounded((int)ch+value,15);
                if(next!=ch){channels[selected]=(uint8_t)next;groove_settings_panel_changed();}
            }
            return;
        }
        if(daw_mode==2) {
            unsigned index=id<2?id+6:id-2,previous=knobs[selected][index];
            unsigned next=bounded((int)previous+value,127);
            if(next!=previous){knobs[selected][index]=(uint8_t)next;cc(ch,CONTROLLER_KNOB_CC+index,next);}
        } else if (id==0) {
            unsigned next=bounded((int)selected+value,CONTROLLER_PRESETS-1);
            if (next!=selected) { selected=(uint8_t)next;channel_overlay=0;groove_settings_panel_changed();controller_link_select(selected,controller_channel()); }
        } else if (id==1) {
            unsigned next=bounded((int)ch+value,15);
            if (next!=ch) { channels[selected]=(uint8_t)next;groove_settings_panel_changed(); }
            channel_at=fm1_millis();channel_overlay=1;
        } else if(daw_mode==1 && (id==2 || id==7)) {
            if(controller_link_active()) {
                int step=page_step(id==2?&preview_steps:&playlist_steps,value);
                if(id==2)controller_link_preview_step(step);else controller_link_playlist_step(step);
            } else preview_steps=playlist_steps=0;
        } else {
            unsigned index=id-2,previous=knobs[selected][index];
            unsigned next=bounded((int)previous+value,127);
            if (next!=previous) { knobs[selected][index]=(uint8_t)next;cc(ch,CONTROLLER_KNOB_CC+index,next); }
        }
    } else if (kind==SMK37_FADER && id<4) {
        unsigned next=bounded(value,127),bit=1U<<id;
        if(daw_mode==1 && id==0) {
            unsigned zone=next<=60?1:next>=67?2:0;
            if(controller_link_active() && zone) {
                if(fade_zone && zone!=fade_zone)controller_link_fadeout(zone==1);
                fade_zone=(uint8_t)zone;
            } else if(!controller_link_active())fade_zone=0;
        } else if ((fader_valid&bit) && next!=faders[id]) cc(ch,CONTROLLER_FADER_CC+id,next);
        faders[id]=(uint8_t)next;fader_valid|=bit;
    } else if (kind==SMK37_PAD && id<16) {
        if (value>0 && pad_channels[id]==255) {
            pad_channels[id]=(uint8_t)ch;cc(ch,CONTROLLER_PAD_CC+id,127);
            if(daw_mode==1 && controller_link_active() && controller_navigation_pad(id)) {
                repeat_at[id]=fm1_millis();repeat_held|=(uint16_t)(1U<<id);repeat_started&=(uint16_t)~(1U<<id);
            }
        } else if (value<=0 && pad_channels[id]!=255) {
            repeat_held&=(uint16_t)~(1U<<id);repeat_started&=(uint16_t)~(1U<<id);
            cc(pad_channels[id],CONTROLLER_PAD_CC+id,0);pad_channels[id]=255;
        }
    } else if (kind==SMK37_KEY && id<37) {
        key_release(id);
        if (value<=0) return;
        unsigned note=(unsigned)(48+(int)id+12*octave);
        if (pedal_down && !(pedal_channels&(1U<<ch))) {
            cc(ch,64,127);pedal_channels|=1U<<ch;
        }
        for (unsigned w=0;w<2;++w)
            if (wheel_values[w]!=(w?0:64) && !(wheel_channels[w]&(1U<<ch))) {
                controller_output_send((w?0xb0:0xe0)|ch,w?1:0,wheel_values[w]);
                wheel_channels[w]|=1U<<ch;
            }
        unsigned already=0;
        for (unsigned i=0;i<37;++i) already|=keys[i].note==note && keys[i].channel==ch;
        keys[id].note=(uint8_t)note;keys[id].channel=(uint8_t)ch;
        if (!already) controller_output_send(0x90|ch,note,bounded(value,127));
    } else if (kind==SMK37_PEDAL) {
        if (value>=64) {
            if (!(pedal_channels&(1U<<ch))) { cc(ch,64,127);pedal_channels|=1U<<ch; }
            pedal_down=1;
        } else {
            for (unsigned i=0;i<16;++i) if (pedal_channels&(1U<<i)) cc(i,64,0);
            pedal_channels=0;pedal_down=0;
        }
    } else if (kind==SMK37_FADER && id<6) {
        unsigned w=id-4,next=bounded(value,127),neutral=w?0:64,bit=1U<<w;
        if ((wheel_valid&bit) && wheel_values[w]==next &&
            (next==neutral || (wheel_channels[w]&(1U<<ch)))) return;
        wheel_valid|=bit;wheel_values[w]=(uint8_t)next;
        unsigned destinations=next==neutral?wheel_channels[w]:1U<<ch;
        for (unsigned i=0;i<16;++i) if (destinations&(1U<<i))
            controller_output_send((w?0xb0:0xe0)|i,w?1:0,next);
        if (next==neutral) wheel_channels[w]=0;else wheel_channels[w]|=1U<<ch;
    } else if (kind==SMK37_BUTTON && id<18) {
        unsigned bit=1U<<id,was=buttons&bit;
        if (value) buttons|=bit;else buttons&=~bit;
        unsigned extra=extra_button(id);
        if(extra<CONTROLLER_EXTRA_BUTTONS && daw_mode!=3) {
            if(value && !was){button_channels[extra]=(uint8_t)ch;cc(ch,controller_extra_cc(extra),127);}
            else if(!value && button_channels[extra]!=255) {
                cc(button_channels[extra],controller_extra_cc(extra),0);button_channels[extra]=255;
            }
        }
        if (value && !was) {
            if(id==11){bluetooth_page=!bluetooth_page;channel_overlay=0;}
            else if ((buttons&(1U<<12)) && (id==2 || id==3)) {
                unsigned next=(daw_mode+(id==3?1:3))%4;
                if(next!=daw_mode) {
                    uint32_t held=buttons;smk37_controls_release();buttons=held;
                    daw_mode=(uint8_t)next;
                    if(daw_mode==3){receiver_volume=(fader_valid&8)?faders[3]:0;controller_audio_enable();}
                    fm1_output_receiver(daw_mode==3,receiver_volume);
                    bluetooth_page=0;channel_overlay=0;preview_steps=playlist_steps=0;
                    fade_zone=(fader_valid&1)?(faders[0]<=60?1:faders[0]>=67?2:0):0;
                    controller_link_mode_changed();groove_settings_panel_changed();
                }
            } else if (id==4 && octave>-4) --octave;
            else if (id==5 && octave<3) ++octave;
        }
    }
    /* Pressure never duplicates pad triggers; auxiliary buttons own separate CCs. */
}
static void navigation_repeat(void)
{
    if(daw_mode!=1 || !controller_link_active()) { repeat_held=repeat_started=0;return; }
    uint32_t now=fm1_millis();
    for(unsigned pad=0;pad<16;++pad) {
        unsigned bit=1U<<pad;
        if(!(repeat_held&bit))continue;
        if(now-repeat_at[pad]<((repeat_started&bit)?80U:400U))continue;
        repeat_at[pad]=now;repeat_started|=(uint16_t)bit;
        controller_output_repeat(0xb0|pad_channels[pad],CONTROLLER_PAD_CC+pad);
    }
}
void smk37_controls_snapshot(struct fm1_controls *out)
{ controller_link_poll();navigation_repeat();controller_output_poll();memset(out,0,sizeof *out);out->knob=1023; }
unsigned smk37_fader_bank(void) { return 0; }
unsigned smk37_pad_steps(void) { return 0; }
unsigned smk37_shift(void) { return buttons&1U; }
unsigned smk37_pad_aftertouch(void) { return 0; }
uint32_t smk37_pad_color(unsigned pad,unsigned lit)
{ (void)lit;return controller_link_pad_color(pad,pad<16 && pad_channels[pad]!=255); }
unsigned smk37_pickup_mask(void) { return 0; }
uint32_t smk37_fader_feedback(void) { return 0; }
unsigned smk37_master_level(void) { return 1023; }
void smk37_master_set(unsigned level) { (void)level; }
void smk37_controls_release(void)
{
    for (unsigned i=0;i<37;++i) key_release(i);
    for (unsigned i=0;i<16;++i) smk37_control_event(SMK37_PAD,i,0);
    for(unsigned i=0;i<CONTROLLER_EXTRA_BUTTONS;++i)if(button_channels[i]!=255) {
        cc(button_channels[i],controller_extra_cc(i),0);button_channels[i]=255;
    }
    smk37_control_event(SMK37_PEDAL,0,0);
    smk37_control_event(SMK37_FADER,4,64);
    smk37_control_event(SMK37_FADER,5,0);
    buttons=0;
}
