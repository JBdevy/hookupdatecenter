/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Controller-task queues: USB congestion never blocks BLE, or vice versa.
 * Preserve press/release ordering; never replay old input after reconnect. */
#include "controller.h"
#include <string.h>
enum { CAPACITY = 128, RECOVERY_STEPS = 20+CONTROLLER_EXTRA_BUTTONS };
struct port_queue {
    uint8_t data[CAPACITY][16], length[CAPACITY];
    unsigned read, write, ready, step;
    uint16_t channels, recovery;
};
static struct port_queue ports[3];
void controller_output_reset(void) { memset(ports, 0, sizeof ports); }
static void recover(struct port_queue *p)
{
    p->read = p->write = p->step = 0;
    p->recovery |= p->channels;
}
void controller_output_panic(void)
{ for (unsigned i=0;i<3;++i) recover(&ports[i]); }
void controller_output_poll(void)
{
    unsigned ready = fm1_midi_ready_ports() & fm1_midi_output_ports();
    for (unsigned i=0;i<3;++i) {
        struct port_queue *p=&ports[i];
        unsigned connected=!!(ready & (1U<<i));
        if (connected != p->ready) { recover(p); p->ready=connected; }
        if (!connected) continue;
        /* Bounded work, including recovery; unavailable/full ports retry on
         * the next control poll. Releases have priority over later presses. */
        for (unsigned work=0;work<32;++work) {
            uint8_t reset[3];
            const uint8_t *m;
            if (p->recovery) {
                unsigned ch=(unsigned)__builtin_ctz(p->recovery);
                reset[0]=(uint8_t)(0xb0|ch); reset[2]=0;
                if (p->step<16) reset[1]=(uint8_t)(CONTROLLER_PAD_CC+p->step);
                else if(p->step<16+CONTROLLER_EXTRA_BUTTONS) reset[1]=(uint8_t)controller_extra_cc(p->step-16);
                else if (p->step==16+CONTROLLER_EXTRA_BUTTONS) reset[1]=64;
                else if (p->step==17+CONTROLLER_EXTRA_BUTTONS) reset[1]=123;
                else if (p->step==18+CONTROLLER_EXTRA_BUTTONS) { reset[0]=(uint8_t)(0xe0|ch); reset[1]=0; reset[2]=64; }
                else reset[1]=1;
                m=reset;
            } else {
                if (p->read==p->write) break;
                m=p->data[p->read & (CAPACITY-1)];
            }
            if (fm1_midi_send_port(i,m,p->recovery?3:p->length[p->read & (CAPACITY-1)])) break;
            if (p->recovery) {
                if (++p->step==RECOVERY_STEPS) {
                    p->recovery &= (uint16_t)(p->recovery-1);
                    p->step=0;
                }
            } else ++p->read;
        }
    }
}
void controller_output_send(unsigned status,unsigned a,unsigned b)
{
    if (status<0x80 || status>=0xf0 || a>127 || b>127) return;
    controller_output_poll();
    for (unsigned i=0;i<3;++i) {
        struct port_queue *p=&ports[i];
        if (!p->ready) continue;
        p->channels |= (uint16_t)(1U<<(status&15));
        if (p->write-p->read>=CAPACITY) recover(p);
        uint8_t *m=p->data[p->write & (CAPACITY-1)];
        m[0]=(uint8_t)status;m[1]=(uint8_t)a;m[2]=(uint8_t)b;
        p->length[p->write & (CAPACITY-1)]=3;
        ++p->write;
    }
    controller_output_poll();
}

void controller_output_sysex(const uint8_t *message,unsigned length)
{
    if (!message || length<9 || length>16 || message[0]!=0xf0 || message[length-1]!=0xf7) return;
    controller_output_poll();
    for (unsigned i=0;i<3;++i) {
        struct port_queue *p=&ports[i];if (!p->ready) continue;
        if (p->write-p->read>=CAPACITY) recover(p);
        memcpy(p->data[p->write&(CAPACITY-1)],message,length);
        p->length[p->write&(CAPACITY-1)]=(uint8_t)length;++p->write;
    }
    controller_output_poll();
}

/* A held navigation pad is a release/press edge to the existing CatLive
 * handlers. Never accumulate repeats behind a stalled USB/BLE port. */
void controller_output_repeat(unsigned status,unsigned number)
{
    if(status<0xb0 || status>0xbf || number>127)return;
    controller_output_poll();
    for(unsigned i=0;i<3;++i) {
        struct port_queue *p=&ports[i];
        if(!p->ready || p->recovery || p->read!=p->write)continue;
        p->channels|=(uint16_t)(1U<<(status&15));
        for(unsigned edge=0;edge<2;++edge) {
            unsigned slot=p->write&(CAPACITY-1);
            p->data[slot][0]=(uint8_t)status;p->data[slot][1]=(uint8_t)number;
            p->data[slot][2]=edge?127:0;p->length[slot]=3;++p->write;
        }
    }
    controller_output_poll();
}
