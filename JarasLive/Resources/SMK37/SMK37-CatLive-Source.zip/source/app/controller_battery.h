/* Raw SMK37 panel thresholds documented in the hardware port; no percent claim.
 * https://github.com/illuminus5/skiff/blob/main/SMK37.md
 * Keep a dead band so small ADC noise cannot flash between charge levels. */
#ifndef CATLIVE_CONTROLLER_BATTERY_H
#define CATLIVE_CONTROLLER_BATTERY_H
static inline unsigned controller_battery_level(unsigned adc, unsigned previous)
{
    static const unsigned edge[3]={530,560,602};
    if(previous>3)return adc<edge[0]?0:adc<edge[1]?1:adc<edge[2]?2:3;
    while(previous<3 && adc>=edge[previous]+4)++previous;
    while(previous>0 && adc+4<edge[previous-1])--previous;
    return previous;
}
#endif
