/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#ifndef CATLIVE_CONTROLLER_H
#define CATLIVE_CONTROLLER_H
#include "fm1.h"
enum { CONTROLLER_PRESETS = 6, CONTROLLER_PAD_CC = 102,
       CONTROLLER_FADER_CC = 20, CONTROLLER_KNOB_CC = 24 };
unsigned controller_preset(void);
unsigned controller_channel(void);
unsigned controller_channel_visible(void);
void controller_preferences_read(uint8_t data[4]);
void controller_preferences_apply(const uint8_t data[4]);
void controller_output_reset(void);
void controller_output_poll(void);
void controller_output_send(unsigned status, unsigned a, unsigned b);
void controller_output_panic(void);
void controller_output_repeat(unsigned status, unsigned number);
static inline unsigned controller_navigation_pad(unsigned pad)
{ return pad<16 && ((0x7878U>>pad)&1U); }
void controller_output_sysex(const uint8_t *message, unsigned length);
int controller_link_receive(const uint8_t *message, unsigned length, unsigned source);
void controller_link_reset(void);
enum { CONTROLLER_EXTRA_BUTTONS=12 };
static inline unsigned controller_extra_cc(unsigned index)
{ static const uint8_t cc[12]={3,9,14,15,85,86,87,88,89,90,118,119};return index<12?cc[index]:255; }
unsigned controller_bluetooth_page(void);
unsigned controller_bluetooth_enabled(void);
void controller_bluetooth_set(unsigned enabled);
void controller_boot_start(void);
unsigned controller_boot_progress(void); /* 0..199 during splash, 200 when finished */
void controller_link_poll(void);
void controller_link_select(unsigned preset, unsigned channel);
void controller_select_remote(unsigned preset);
const char *controller_link_title(void);
uint32_t controller_link_title_color(void);
uint32_t controller_link_pad_color(unsigned pad, unsigned held);
unsigned controller_link_revision(void);
unsigned controller_mode(void);
unsigned controller_audio_volume(void);
void controller_audio_enable(void);
unsigned controller_link_recording(void);
unsigned controller_link_navigation(void);
const char *controller_link_row(unsigned row);
unsigned controller_link_playback(void);
unsigned controller_link_progress(void);
unsigned controller_link_elapsed(void);
unsigned controller_link_duration(void);
unsigned controller_link_fading(void);
unsigned controller_link_fade_tenths(void);
unsigned controller_link_fade_fraction(void);
unsigned controller_link_looping(void);
unsigned controller_link_blink(void);
unsigned controller_wrap_title(const char *title, char lines[4][20]);
void controller_link_mode_changed(void);
unsigned controller_link_active(void);
void controller_link_preview_step(int step);
void controller_link_playlist_step(int step);
void controller_link_fadeout(unsigned active);
#endif
