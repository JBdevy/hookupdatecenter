/* CatLive controller: a modest boost to attack detection only.
 * Raw pressure, adaptive noise floor, release hysteresis and debounce stay
 * unchanged. No floating point, allocation or extra work while below floor. */
#ifndef CATLIVE_PAD_SENSITIVITY_H
#define CATLIVE_PAD_SENSITIVITY_H
static inline int catlive_pad_attack_sample(int sample,int floor)
{
    if(sample<=floor)return sample;
    int boosted=sample+(sample-floor)/4;
    return boosted>1023?1023:boosted;
}
/* Two consecutive full-scale attacks qualify even without a gradual rising
 * window. One ADC spike alone cannot start a pad. Release debounce still owns
 * re-arming, so a held pad emits only once. */
static inline int catlive_pad_strong_attack(int previous,int current)
{
    return previous>=1023 && current>=1023;
}
#endif
