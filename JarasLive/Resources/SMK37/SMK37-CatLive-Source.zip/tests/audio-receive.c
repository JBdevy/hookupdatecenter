#include "audio_output.h"
#include "fm1_audio_io.h"
#include <assert.h>
#include <stdio.h>
static unsigned bluetooth_on,usb_on;
static int16_t bluetooth_sample=1000;
static int32_t capture[FM1_BLOCK_WORDS];
unsigned fm1_engine_output_level(void){ return 0; }
int fm1_usb_audio_read(int32_t *pcm,unsigned frames,uint16_t gains[2]) {
 gains[0]=gains[1]=128;
 for(unsigned i=0;i<FM1_BLOCK_WORDS;i++)pcm[i]=2000;
 return usb_on?frames:0;
}
int fm1_bluetooth_audio_read(int16_t *pcm,unsigned frames) {
 for(unsigned i=0;i<FM1_BLOCK_WORDS;i++)pcm[i]=bluetooth_sample;
 return bluetooth_on?frames:0;
}
int fm1_usb_audio_write(const int32_t *pcm,unsigned frames) {
 for(unsigned i=0;i<FM1_BLOCK_WORDS;i++)capture[i]=pcm[i];return frames;
}
static void settle(unsigned level) {
 fm1_output_receiver(1,level);
 for(unsigned block=0;block<20;block++) {
  int32_t pcm[FM1_BLOCK_WORDS];
  for(unsigned i=0;i<FM1_BLOCK_WORDS;i++)pcm[i]=8000000; /* synth must be suppressed */
  fm1_output_mix(pcm);
 }
}
int main(void) {
 fm1_output_reset();bluetooth_on=1;settle(127);
 for(unsigned i=0;i<FM1_BLOCK_WORDS;i++)assert(capture[i]==254000);
 settle(64);assert(capture[0]==128000);
 settle(0);assert(capture[0]==0);
 bluetooth_on=0;settle(127);assert(capture[0]==0);
 usb_on=1;settle(127);assert(capture[0]>0 && capture[0]<2000);
 bluetooth_on=1;bluetooth_sample=32767;settle(127);assert(capture[0]<=8388607);
 fm1_output_receiver(0,127);
 for(unsigned b=0;b<20;b++){int32_t pcm[FM1_BLOCK_WORDS]={0};fm1_output_mix(pcm);}
 assert(capture[0]==0); /* restored ordinary engine master */
 puts("AUDIO_RECEIVE_BLUETOOTH_USB_FADER_MUTE_SYNTH_SUPPRESSION_OK");
}
