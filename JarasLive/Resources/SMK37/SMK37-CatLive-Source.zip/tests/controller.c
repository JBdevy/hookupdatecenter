#include "smk37_controls.h"
#include "controller.h"
#include "board/pad_sensitivity.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
struct event { unsigned port; uint8_t bytes[3]; };
static struct event log_events[65536];
static unsigned count,ready=6,busy,settings_changed,sysex_count;
static uint8_t sysex_log[256][128];
static unsigned sysex_lengths[256];
void fm1_control_request(void) {}
static unsigned receiver_enabled,receiver_gain;
void fm1_output_receiver(unsigned enabled,unsigned level){receiver_enabled=enabled;receiver_gain=level;}
void controller_audio_enable(void);
static uint32_t now;
static unsigned bluetooth_enabled=1;
unsigned controller_bluetooth_enabled(void){return bluetooth_enabled;}
void controller_bluetooth_set(unsigned enabled){bluetooth_enabled=!!enabled;}
void controller_audio_enable(void){bluetooth_enabled=1;}
unsigned fm1_midi_ready_ports(void) { return ready; }
unsigned fm1_midi_output_ports(void) { return 6; }
uint32_t fm1_millis(void) { return now; }
void groove_settings_panel_changed(void) { ++settings_changed; }
int fm1_midi_send_port(unsigned port,const uint8_t *m,size_t n)
{
    assert(port<3 && n>=3 && n<=128);
    if(m[0]!=0xf0)assert(n==3 && m[0]>=128 && m[0]<240 && m[1]<128 && m[2]<128);
    if (!(ready&(1U<<port))) return -1;
    if (busy&(1U<<port)) return -2;
    if(m[0]==0xf0) {
        assert(n>=9 && m[n-1]==0xf7 && sysex_count<256);
        unsigned sum=0;for(unsigned i=1;i<n-1;++i){assert(m[i]<128);sum+=m[i];}assert(!(sum&127));
        memcpy(sysex_log[sysex_count],m,n);sysex_lengths[sysex_count++]=(unsigned)n;return 0;
    }
    assert(count<sizeof log_events/sizeof *log_events);
    log_events[count].port=port;memcpy(log_events[count++].bytes,m,3);return 0;
}
static void expect(unsigned index,unsigned port,unsigned status,unsigned a,unsigned b)
{ assert(index<count);assert(log_events[index].port==port);assert(log_events[index].bytes[0]==status);assert(log_events[index].bytes[1]==a);assert(log_events[index].bytes[2]==b); }
static void event(unsigned kind,unsigned id,int value) { smk37_control_event(kind,id,value); }
static void reset(void) { count=sysex_count=0;ready=6;busy=0;now=0;settings_changed=0;smk37_controls_reset(); }
static void tick(void) { struct fm1_controls s;smk37_controls_snapshot(&s);assert(s.buttons==0 && s.keys==0);for(unsigned i=0;i<7;++i)assert(!s.encoders[i]); }
static unsigned frame(uint8_t *out,unsigned command,const uint8_t *data,unsigned n) {
    const uint8_t sig[]={0xf0,0x7d,'C','L','S',1};memcpy(out,sig,6);out[6]=(uint8_t)command;
    if(n)memcpy(out+7,data,n);unsigned sum=0;for(unsigned i=1;i<n+7;++i)sum+=out[i];
    out[n+7]=(uint8_t)((128-(sum&127))&127);out[n+8]=0xf7;return n+9;
}
static void host(unsigned command,const uint8_t *data,unsigned n) {
    uint8_t message[128];unsigned length=frame(message,command,data,n);
    assert(controller_link_receive(message,length,1));tick();
}
static void named(unsigned command,const char *name) {
    uint8_t data[80]={15,15,8,0,2,0};unsigned n=(unsigned)strlen(name);memcpy(data+6,name,n);host(command,data,n+6);
}
static void flags(unsigned value) {uint8_t v=(uint8_t)value;host(0x14,&v,1);}
static void title(const char *expected) {assert(!strcmp(controller_link_title(),expected));}
static void mode(unsigned daw) {
    for(unsigned i=0;i<4 && controller_mode()!=daw;++i) {
        event(SMK37_BUTTON,12,1);event(SMK37_BUTTON,3,1);
        event(SMK37_BUTTON,3,0);event(SMK37_BUTTON,12,0);
    }
    assert(controller_mode()==daw);
}
int main(void)
{
    reset();event(SMK37_FADER,3,64);mode(3);
    assert(receiver_enabled && receiver_gain==64 && controller_bluetooth_enabled());
    title("AUDIO RECEIVE");unsigned receiver_events=count;
    event(SMK37_FADER,3,127);assert(receiver_gain==127 && count==receiver_events);
    event(SMK37_FADER,3,0);assert(receiver_gain==0);
    event(SMK37_PAD,8,127);event(SMK37_PAD,8,0);event(SMK37_KEY,0,100);event(SMK37_KEY,0,0);
    event(SMK37_ENCODER,0,10);assert(count==receiver_events);
    host(1,0,0);assert(sysex_log[sysex_count-1][9]==2); /* Free on existing host protocol. */
    title("AUDIO RECEIVE");
    uint8_t audio_prefs[4];controller_preferences_read(audio_prefs);reset();controller_preferences_apply(audio_prefs);
    assert(controller_mode()==3 && receiver_enabled && receiver_gain==0);
    mode(0);assert(!receiver_enabled);
    const unsigned extra_ids[12]={0,1,6,7,8,9,10,13,14,15,16,17};
    for(unsigned m=0;m<3;++m) {
        reset();mode(m);
        for(unsigned i=0;i<12;++i) {
            unsigned at=count;event(SMK37_BUTTON,extra_ids[i],1);event(SMK37_BUTTON,extra_ids[i],1);
            event(SMK37_BUTTON,extra_ids[i],0);event(SMK37_BUTTON,extra_ids[i],0);
            assert(count==at+4);
            expect(at,1,0xb0,controller_extra_cc(i),127);expect(at+1,2,0xb0,controller_extra_cc(i),127);
            expect(at+2,1,0xb0,controller_extra_cc(i),0);expect(at+3,2,0xb0,controller_extra_cc(i),0);
        }
        unsigned at=count;
        event(SMK37_BUTTON,11,1);event(SMK37_BUTTON,11,0);assert(controller_bluetooth_page());
        event(SMK37_ENCODER,3,-1);assert(!bluetooth_enabled);
        event(SMK37_ENCODER,3,1);assert(bluetooth_enabled);
        event(SMK37_ENCODER,4,999);assert(controller_channel()==15);
        event(SMK37_ENCODER,4,-999);assert(controller_channel()==0);
        assert(count==at); /* configuration knobs never leak mapping CCs */
        event(SMK37_BUTTON,11,1);event(SMK37_BUTTON,11,0);assert(!controller_bluetooth_page());
    }
    reset();event(SMK37_BUTTON,6,1);event(SMK37_ENCODER,1,1);event(SMK37_BUTTON,6,0);
    expect(2,1,0xb0,14,0); /* release on original MIDI channel */
    reset();event(SMK37_BUTTON,0,1);mode(1);expect(2,1,0xb0,3,0);
    unsigned after_release=count;event(SMK37_BUTTON,0,0);assert(count==after_release);
    reset();busy=2;event(SMK37_BUTTON,17,1);event(SMK37_BUTTON,17,0);
    expect(0,2,0xb0,119,127);expect(1,2,0xb0,119,0);
    busy=0;tick();expect(2,1,0xb0,119,127);expect(3,1,0xb0,119,0);
    reset();event(SMK37_BUTTON,0,1);ready=4;tick();count=0;ready=6;tick();
    unsigned cleared=0;for(unsigned i=0;i<count;++i)if(log_events[i].port==1&&log_events[i].bytes[1]==3&&log_events[i].bytes[2]==0)cleared=1;
    assert(cleared); /* reconnect clears auxiliary CCs as well as pads */
    reset();ready=4; /* Bluetooth MIDI alone, USB disconnected. */
    uint8_t ble_hello[16];unsigned ble_length=frame(ble_hello,1,0,0);
    assert(controller_link_receive(ble_hello,ble_length,2));tick();assert(controller_link_active());
    event(SMK37_BUTTON,13,1);event(SMK37_BUTTON,13,0);
    assert(count==2);expect(0,2,0xb0,88,127);expect(1,2,0xb0,88,0);
    const char *ble_title="Bluetooth Ready";uint8_t ble_data[80]={15,0,0,0,15,0};
    memcpy(ble_data+6,ble_title,strlen(ble_title));uint8_t ble_message[128];
    ble_length=frame(ble_message,0x13,ble_data,(unsigned)strlen(ble_title)+6);
    assert(controller_link_receive(ble_message,ble_length,2));tick();
    title(ble_title); /* feedback names work over BLE as well */
    reset();controller_boot_start();
    assert(controller_boot_progress()==0);
    host(1,0,0);assert(controller_link_active()); /* USB handshake continues during splash. */
    for(unsigned step=0;step<50;++step) {
        now=step*40U;assert(controller_boot_progress()==step*4U);
        unsigned phase=step%32,position=phase%16,selected=position<8?position:23-position;
        for(unsigned pad=0;pad<16;++pad)
            assert(controller_link_pad_color(pad,0)==(pad==selected?(phase<16?0x0b331c:0x26073f):0));
    }
    now=1999;assert(controller_boot_progress()==199);
    now=2000;assert(controller_boot_progress()==200);
    assert(controller_link_pad_color(5,0)!=0); /* connected colors immediately restored */
    now=0;assert(controller_boot_progress()==200); /* completed splash cannot return on clock wrap */
    reset();now=0xfffffff0U;controller_boot_start();now+=1000U;assert(controller_boot_progress()==100);
    now+=1000U;assert(controller_boot_progress()==200);
    reset();title("AGUARDANDO CONEXAO");
    /* Every pad is an independent CC, including a release with no duplicate
       on velocity/pressure. USB and BLE receive the exact same messages. */
    for(unsigned i=0;i<16;++i) {
        unsigned at=count;
        event(SMK37_PAD,i,1);event(SMK37_PRESSURE,i,90);event(SMK37_PAD,i,100);
        event(SMK37_PAD,i,0);event(SMK37_PAD,i,0);
        assert(count==at+4);
        expect(at,1,0xb0,102+i,127);expect(at+1,2,0xb0,102+i,127);
        expect(at+2,1,0xb0,102+i,0);expect(at+3,2,0xb0,102+i,0);
    }
    reset();
    for(unsigned i=0;i<4;++i) {
        unsigned at=count;
        event(SMK37_FADER,i,40);assert(count==at); /* boot ADC is not a gesture */
        event(SMK37_FADER,i,127);event(SMK37_FADER,i,127);event(SMK37_FADER,i,-9);
        assert(count==at+4);expect(at,1,0xb0,20+i,127);expect(at+2,1,0xb0,20+i,0);
    }
    for(unsigned i=2;i<8;++i) {
        unsigned at=count;event(SMK37_ENCODER,i,1);expect(at,1,0xb0,24+i-2,65);
        event(SMK37_ENCODER,i,999);expect(at+2,1,0xb0,24+i-2,127);
        event(SMK37_ENCODER,i,-999);expect(at+4,1,0xb0,24+i-2,0);
    }
    assert(smk37_master_level()==1023); /* F4/K8 no longer modify audio gain. */
    reset();
    for(unsigned p=0;p<6;++p) {
        assert(controller_preset()==p && controller_channel()==0);
        event(SMK37_ENCODER,1,p+1);assert(controller_channel()==p+1);
        event(SMK37_ENCODER,0,1);
    }
    assert(controller_preset()==5 && count==0); /* Navigation sends SysEx, never unsolicited note/CC triggers. */
    event(SMK37_ENCODER,0,-999);assert(controller_preset()==0 && controller_channel()==1);
    event(SMK37_ENCODER,1,999);assert(controller_channel()==15);
    event(SMK37_PAD,0,10);expect(0,1,0xbf,102,127);
    event(SMK37_ENCODER,1,-999);assert(controller_channel()==0);
    event(SMK37_PAD,0,0);expect(2,1,0xbf,102,0); /* release uses original channel */
    uint8_t prefs[4];controller_preferences_read(prefs);
    smk37_controls_reset();controller_preferences_apply(prefs);assert(controller_channel()==0);
    for(unsigned p=1;p<6;++p) { event(SMK37_ENCODER,0,1);assert(controller_channel()==p+1); }
    unsigned prev=controller_preset();uint8_t old_synth[4]={1,2,2,2};controller_preferences_apply(old_synth);assert(controller_preset()==prev);
    reset();now=100;event(SMK37_ENCODER,1,1);assert(controller_channel_visible());
    now=2099;assert(controller_channel_visible());now=2100;assert(!controller_channel_visible());
    now=0xfffffff0U;event(SMK37_ENCODER,1,1);now=0x000007bfU;assert(controller_channel_visible());
    now=0x000007c0U;assert(!controller_channel_visible()); /* wrap-safe two seconds */
    event(SMK37_ENCODER,1,1);event(SMK37_ENCODER,0,1);assert(!controller_channel_visible());
    reset();event(SMK37_KEY,0,100);event(SMK37_ENCODER,1,1);event(SMK37_KEY,0,0);
    expect(0,1,0x90,48,100);expect(2,1,0x80,48,0);
    event(SMK37_KEY,1,100);expect(4,1,0x91,49,100);event(SMK37_KEY,1,0);
    event(SMK37_PEDAL,0,127);event(SMK37_ENCODER,1,1);event(SMK37_KEY,2,100);
    event(SMK37_PEDAL,0,0);expect(count-4,1,0xb1,64,0);expect(count-2,1,0xb2,64,0);
    smk37_controls_release();
    reset();busy=2;event(SMK37_PAD,4,100);event(SMK37_PAD,4,0);
    assert(count==2);expect(0,2,0xb0,106,127);expect(1,2,0xb0,106,0);
    busy=0;tick();assert(count==4);expect(2,1,0xb0,106,127);expect(3,1,0xb0,106,0);
    reset();busy=2;
    for(unsigned i=0;i<300;++i) { event(SMK37_PAD,i%16,100);event(SMK37_PAD,i%16,0); }
    busy=0;for(unsigned i=0;i<20;++i)tick();
    /* Overflow recovery must leave every custom pad CC low on USB. */
    unsigned levels[16]={0};
    for(unsigned i=0;i<count;++i) if(log_events[i].port==1 && log_events[i].bytes[0]==0xb0 && log_events[i].bytes[1]>=102 && log_events[i].bytes[1]<=117) levels[log_events[i].bytes[1]-102]=log_events[i].bytes[2];
    for(unsigned i=0;i<16;++i)assert(levels[i]==0);
    reset();event(SMK37_PAD,0,100);ready=4;tick();count=0;event(SMK37_PAD,1,100);event(SMK37_PAD,1,0);
    ready=6;for(unsigned i=0;i<20;++i)tick();
    for(unsigned i=0;i<count;++i) if(log_events[i].port==1) assert(!(log_events[i].bytes[0]==0xb0 && log_events[i].bytes[1]>=102 && log_events[i].bytes[1]<=117 && log_events[i].bytes[2]));
    reset();event(SMK37_BUTTON,3,1);event(SMK37_BUTTON,3,0);assert(controller_mode()==0);
    mode(1);uint8_t mode_prefs[4];controller_preferences_read(mode_prefs);
    smk37_controls_reset();controller_preferences_apply(mode_prefs);assert(controller_mode()==1);mode(0);
    reset();mode(1);host(1,0,0);assert(sysex_log[sysex_count-1][6]==0x41);
    unsigned cc_before=count,packets=sysex_count;
    for(unsigned i=0;i<3;++i)event(SMK37_ENCODER,2,-1);
    assert(sysex_count==packets);event(SMK37_ENCODER,2,-1);
    assert(count==cc_before && sysex_log[sysex_count-1][6]==0x23 && sysex_log[sysex_count-1][7]==63);
    event(SMK37_ENCODER,2,999);assert(sysex_log[sysex_count-1][7]==127);
    packets=sysex_count;event(SMK37_ENCODER,2,3);event(SMK37_ENCODER,2,-3);assert(sysex_count==packets);
    event(SMK37_ENCODER,2,-1);assert(sysex_log[sysex_count-1][7]==63);
    event(SMK37_ENCODER,7,4);assert(sysex_log[sysex_count-1][6]==0x24 && sysex_log[sysex_count-1][7]==65);
    packets=sysex_count;event(SMK37_FADER,0,127);event(SMK37_FADER,0,64);assert(sysex_count==packets);
    event(SMK37_FADER,0,60);assert(sysex_log[sysex_count-1][6]==0x25 && sysex_log[sysex_count-1][7]==1);
    packets=sysex_count;event(SMK37_FADER,0,61);event(SMK37_FADER,0,66);assert(sysex_count==packets);
    event(SMK37_FADER,0,67);assert(sysex_log[sysex_count-1][7]==0);
    assert(count==cc_before);
    flags(0);assert(controller_link_pad_color(8,0)==0x0b331c);
    assert(controller_link_pad_color(1,1)==0x060606 && controller_link_pad_color(2,0)==0x060606 && controller_link_pad_color(7,0)==0x060606 && controller_link_pad_color(9,0)==0x060606 && controller_link_pad_color(10,0)==0x060606 && controller_link_pad_color(15,0)==0x060606);
    for(unsigned i=0;i<16;++i) {
        uint32_t idle=controller_link_pad_color(i,0),held=controller_link_pad_color(i,1);
        if(controller_navigation_pad(i)) {
            for(unsigned shift=0;shift<=16;shift+=8) {
                unsigned a=(idle>>shift)&255,b=(held>>shift)&255;assert(b>=2*a && b<=2*a+1);
            }
        } else assert(idle==held);
    }
    flags(32);assert(controller_link_pad_color(8,0)==0x3f0808);
    flags(33);assert(controller_link_pad_color(8,1)==0x060606 && controller_link_pad_color(9,0)==0x3f3611);
    flags(64|16|8);assert(controller_link_pad_color(15,0)==0x26073f && controller_link_pad_color(2,0)==0x3f3f3f && controller_link_pad_color(7,0)==0x0b331c);
    flags(4);assert(controller_link_pad_color(10,0)!=0);now=500;tick();assert(controller_link_pad_color(10,1)==0);now=0;tick();
    mode(2);title("DAW CONTROLLER FREE");packets=sysex_count;cc_before=count;
    for(unsigned i=0;i<8;++i)event(SMK37_ENCODER,i,1);
    assert(sysex_count==packets && count==cc_before+16);
    expect(cc_before,1,0xb0,30,65);expect(cc_before+2,1,0xb0,31,65);
    event(SMK37_FADER,0,127);expect(count-2,1,0xb0,20,127);
    uint8_t free_prefs[4];controller_preferences_read(free_prefs);smk37_controls_reset();controller_preferences_apply(free_prefs);assert(controller_mode()==2);
    reset();mode(1);host(1,0,0);
    flags(1);title("PAUSE");named(0x13,"AUTO ATIVO");title("AUTO ATIVO");
    now=1999;tick();title("AUTO ATIVO");now=2000;tick();title("PAUSE");
    flags(2);title("REC");assert(controller_link_recording());
    now=2500;tick();assert(!controller_link_blink());assert(controller_link_title_color()==0);
    now=3000;host(1,0,0);tick();assert(controller_link_blink());assert(controller_link_title_color()!=0);
    named(0x13,"Nome de musica selecionada com quebra de linha");
    flags(3);title("Nome de musica selecionada com quebra de linha");
    now=5000;host(1,0,0);title("PAUSE");assert(controller_link_recording());
    named(0x15,"REFRAO");flags(4);title("REFRAO");assert(controller_link_looping());
    named(0x13,"BLOCO 5-8");title("BLOCO 5-8");now=7000;host(1,0,0);title("REFRAO");
    flags(0);title("DAW CONTROLLER");
    /* Invalid/truncated/foreign frames and unpaired ports cannot change UI. */
    uint8_t bytes[128],bad_flags=1;unsigned n=frame(bytes,0x14,&bad_flags,1);
    assert(controller_link_receive(bytes,n,2));tick();title("DAW CONTROLLER");
    bytes[n-2]^=1;assert(controller_link_receive(bytes,n,1));tick();title("DAW CONTROLLER");
    assert(controller_link_receive(bytes,n-2,1));tick();title("DAW CONTROLLER");
    bytes[1]=0x41;assert(!controller_link_receive(bytes,n,1));
    /* Pad names and RGB metadata are bank-specific and expiry returns preset. */
    mode(0);uint8_t preset_meta[]={0,1,2,3,4,5,6,'M','E','T','A','I','S'};
    host(0x10,preset_meta,sizeof preset_meta);title("PADS FX CONTROLLER");now=9000;host(1,0,0);title("METAIS");assert(controller_link_title_color()==0x123456);
    uint8_t pad_meta[]={0,2,15,0,0,15,2,3,'B','R','A','S','S',' ','H','I','T'};
    host(0x11,pad_meta,sizeof pad_meta);uint8_t state[]={0,2,1,4,0,0};host(0x12,state,6);
    title("BRASS HIT");assert(controller_link_title_color()==0xf00f23);
    assert(controller_link_pad_color(2,0)==controller_link_pad_color(2,1));
    uint32_t stable=controller_link_pad_color(2,0);state[3]=0;host(0x12,state,6);assert(controller_link_pad_color(2,0)!=stable);assert(controller_link_pad_color(2,0)==0x140102);assert(controller_link_pad_color(2,0)==controller_link_pad_color(2,1));
    now=11000;host(1,0,0);title("METAIS");
    mode(1);flags(7);now=14500;tick();title("AGUARDANDO CONEXAO");assert(!controller_link_recording() && !controller_link_looping());
    char lines[4][20];unsigned rows=controller_wrap_title("Nome da musica com palavras e um nome comprido para testar",lines);
    assert(rows==4);for(unsigned i=0;i<rows;++i)assert(strlen(lines[i])<=19);
    assert(!strcmp(lines[0],"Nome da musica com"));
    assert(controller_wrap_title("                    ",lines)==0);
    assert(controller_wrap_title("ABCDEFGHIJKLMNOPQRSTUV",lines)==2);
    reset();mode(1);busy=2;host(1,0,0);unsigned before_reply=sysex_count;
    busy=0;tick();assert(sysex_count>before_reply); /* busy hello response retries */
    /* Keyboard-like repeat only for navigation, with bounded output and
       immediate release cancellation. Controls and FX pads stay single-shot. */
    for(unsigned pad=0;pad<16;++pad) {
        reset();host(1,0,0);mode(1);count=0;
        event(SMK37_PAD,pad,127);assert(count==2);
        now=399;tick();assert(count==2);
        now=400;tick();unsigned repeated=controller_navigation_pad(pad)?4:0;
        assert(count==2+repeated);
        if(repeated) {expect(2,1,0xb0,102+pad,0);expect(3,1,0xb0,102+pad,127);}
        now=479;tick();assert(count==2+repeated);now=480;tick();assert(count==2+2*repeated);
        event(SMK37_PAD,pad,0);unsigned stopped=count;now=1000;tick();assert(count==stopped);
    }
    for(unsigned free_mode=0;free_mode<3;free_mode+=2) {
        reset();host(1,0,0);mode(free_mode);count=0;event(SMK37_PAD,11,127);
        now=1000;tick();assert(count==2);event(SMK37_PAD,11,0);
    }
    reset();host(1,0,0);mode(1);event(SMK37_PAD,11,127);event(SMK37_ENCODER,1,1);
    count=0;now=400;tick();expect(0,1,0xb0,113,0);expect(1,1,0xb0,113,127);
    event(SMK37_PAD,11,0);expect(4,1,0xb0,113,0); /* release on original channel */
    reset();host(1,0,0);mode(1);event(SMK37_PAD,11,127);now=4000;tick();count=0;
    host(1,0,0);now=4400;tick();assert(count==0); /* no old hold on reconnect */
    reset();host(1,0,0);mode(1);event(SMK37_PAD,11,127);mode(0);count=0;now=500;tick();assert(count==0);
    reset();host(1,0,0);mode(1);now=0xfffffff0U;host(1,0,0);event(SMK37_PAD,11,127);count=0;
    now=0x180U;tick();assert(count==4); /* wrap-safe delay */
    reset();host(1,0,0);mode(1);busy=2;event(SMK37_PAD,11,127);
    for(now=400;now<2000;now+=80)tick();count=0;busy=0;tick();
    unsigned usb=0;for(unsigned i=0;i<count;++i)usb+=log_events[i].port==1;
    assert(usb<=3);event(SMK37_PAD,11,0); /* stalled port cannot build a repeat burst */
    reset();host(1,0,0);mode(1);flags(32);
    uint8_t fade[3]={1,50,127};host(0x16,fade,3);
    assert(controller_link_fading() && controller_link_fade_tenths()==50 && controller_link_fade_fraction()==127);
    fade[1]=25;fade[2]=64;host(0x16,fade,3);assert(controller_link_fade_tenths()==25 && controller_link_fade_fraction()==64);
    fade[1]=99;host(0x16,fade,3);assert(controller_link_fade_tenths()==25);
    flags(0);assert(!controller_link_fading());flags(32);
    fade[0]=0;fade[1]=0;fade[2]=0;host(0x16,fade,3);assert(!controller_link_fading());
    named(0x13,"FADE OUT CANCELADO");title("FADE OUT CANCELADO");now=2000;tick();title("DAW CONTROLLER");
    fade[0]=1;fade[1]=20;host(0x16,fade,3);now=6000;tick();assert(!controller_link_fading());
    reset();host(1,0,0);mode(1);flags(32);
    uint8_t nav_rows[]={3,1,'A',1,'B',1,'C',1,'D',1,'E'};host(0x17,nav_rows,sizeof nav_rows);
    assert(controller_link_navigation()==3 && !strcmp(controller_link_row(2),"C"));
    host(0x17,nav_rows,sizeof nav_rows-1);assert(!strcmp(controller_link_row(4),"E"));
    nav_rows[4]=1;host(0x17,nav_rows,sizeof nav_rows);assert(!strcmp(controller_link_row(1),"B"));nav_rows[4]='B';
    uint8_t progress[]={100,0,30,0,0,60,0,0};host(0x18,progress,8);
    assert(controller_link_playback() && controller_link_progress()==100 && controller_link_elapsed()==30 && controller_link_duration()==60);
    progress[0]=127;progress[1]=127;host(0x18,progress,8);assert(controller_link_progress()==100);
    progress[0]=100;progress[1]=0;progress[2]=61;host(0x18,progress,8);assert(controller_link_elapsed()==30);
    now=2000;tick();assert(!controller_link_navigation() && controller_link_playback());
    host(0x17,nav_rows,sizeof nav_rows);named(0x13,"STOP");assert(!controller_link_navigation());
    flags(0);assert(!controller_link_playback());flags(1);assert(controller_link_playback());
    host(0x17,nav_rows,sizeof nav_rows);mode(2);assert(!controller_link_navigation() && !controller_link_playback());
    mode(1);host(0x17,nav_rows,sizeof nav_rows);host(2,0,0);assert(!controller_link_navigation() && !controller_link_playback());
    for(int floor=0;floor<=100;++floor)for(int sample=0;sample<=1023;++sample) {
        int attack=catlive_pad_attack_sample(sample,floor);
        assert(attack>=sample && attack<=1023);
        if(sample<=floor)assert(attack==sample);
        if(sample)assert(attack>=catlive_pad_attack_sample(sample-1,floor));
    }
    assert(!catlive_pad_strong_attack(0,1023));
    assert(!catlive_pad_strong_attack(1023,900));
    assert(catlive_pad_strong_attack(1023,1023));
    assert(catlive_pad_attack_sample(430,100)>=512);
    assert(catlive_pad_attack_sample(200,100)<300);
    reset();
    for(unsigned step=0;step<33;++step) {
        now=step*40U;tick();unsigned position=step%16U;
        unsigned selected=position<8U?position:23U-position;
        for(unsigned pad=0;pad<16;++pad) {
            uint32_t expected=pad==selected?((step/16U)%2?0x26073f:0x0b331c):0;
            assert(controller_link_pad_color(pad,0)==expected);
            assert(controller_link_pad_color(pad,1)==expected);
        }
    }
    assert(count==0 && sysex_count==0);
    mode(1);host(1,0,0);flags(0);
    assert(controller_link_pad_color(8,0)==0x0b331c && controller_link_pad_color(1,0)==0x060606);
    host(2,0,0);assert(controller_link_pad_color(0,0)==0x0b331c && controller_link_pad_color(8,0)==0);
    host(1,0,0);now+=3500;tick();assert(!controller_link_active());
    assert(controller_link_pad_color(0,0)==0x0b331c);
    puts("CONTROLLER_OK: 16 pads, 4 faders, K1/K2 navigation, K3-K8, 6 presets, channels 1-16, persistence, 2-second display, held releases, busy/reconnect/overflow");
}
