from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
s=(root/'source/app/board/scan.c').read_text()
body=s[s.index('s16 padgate[PAD_CNT];'):s.index('//--------------------mp--------------------')]
body=body.replace('__attribute__((section(".data.smk37_scan")))','')
head='''#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "board/pad_sensitivity.h"
typedef int16_t s16; typedef int32_t s32; typedef uint8_t u8; typedef uint16_t u16;
#define FM1_AUDIO_CODE
#define PAD_CNT 16
#define PADKEY_JUDGE 4
#define PADKEY_DNJET 12
#define PADKEY_UPJET 24
#define PADADC_JUDGE 10
#define PADADC_JET 16
#define PADADC_JET_OFFSET 4
#define PADADC_MSG(id,v) (0x10000|(v))
#define PADKEY_MSG(id,v) (v)
static int on,off;
static void kbd_hw_msg_wr_atom(int value) { if(value&0x10000)return; if(value)++on;else ++off; }
static struct {short pad[16][2];} trim_vm_cfg;
// SDK's four-sample rising-window contract, verified against the matching binary.
static unsigned smk37_pad_history_step(int16_t h[4],int v) {
 h[0]=h[1];h[1]=h[2];h[2]=h[3];h[3]=v>300?v:h[3];
 unsigned i=0;while(i<3 && h[i]<h[i+1])++i;return i;
}
'''
tail='''
static void reset(void) { memset(padkey,0,sizeof padkey);memset(padadc,0,sizeof padadc);on=off=0;padgate[0]=100;trim_vm_cfg.pad[0][0]=100; }
static void feed(int value,int count){for(int i=0;i<count;++i)pad_prc(0,value);}
int main(void){
 reset(); int clipped[]={100,700,800,850,900,960,1023,1023,1023,100};
 for(unsigned i=0;i<sizeof(clipped)/sizeof(clipped[0]);++i)feed(clipped[i],1);
 printf("strong ramp on=%d\\n",on);int ramp=on;
 reset();feed(100,20);feed(1023,30);printf("abrupt plateau on=%d\\n",on);int abrupt=on;
 feed(1023,500);assert(on==abrupt);feed(0,400);assert(off==abrupt);
 feed(1023,30);int repeat=on;printf("repeat on=%d\\n",repeat);
 reset();for(int n=0;n<100;++n){feed(1023,1);feed(0,40);}assert(on==0);
 reset();for(int n=0;n<10000;++n)feed(90+n%20,1);assert(on==0);
 reset();for(int n=100;n<500;n+=10)feed(n,1);feed(500,30);int gentle=on;printf("gentle on=%d\\n",gentle);
 if(ramp!=1||abrupt!=1||repeat!=2||gentle!=1)return 1;
 assert(pad_trim(1023,0)<=1023);
 puts("PAD_SCAN_STRONG_GENTLE_HOLD_RELEASE_RETRIGGER_NOISE_OK");
}
'''
p=Path('/tmp/smk-pad-scan-test.c');p.write_text(head+body+tail)
subprocess.run(['clang','-std=c11','-fsanitize=address,undefined','-g','-I'+str(root/'source/app'),str(p),'-o','/tmp/smk-pad-scan-test'],check=True)
r=subprocess.run(['/tmp/smk-pad-scan-test']);raise SystemExit(r.returncode)
