#include "controller_battery.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
 assert(controller_battery_level(500,4)==0);
 assert(controller_battery_level(545,4)==1);
 assert(controller_battery_level(580,4)==2);
 assert(controller_battery_level(650,4)==3);
 assert(controller_battery_level(531,0)==0);
 assert(controller_battery_level(535,0)==1);
 assert(controller_battery_level(529,1)==1);
 assert(controller_battery_level(525,1)==0);
 assert(controller_battery_level(500,3)==0);
 puts("BATTERY_THREE_LEVELS_LOW_AND_HYSTERESIS_OK");
}
