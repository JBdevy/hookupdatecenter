# Using M-Flasher

## Installing

**Windows** (10 or 11). Extract `M-Flasher-…-windows.zip` and run
`M-Flasher.exe`. When it finds the unit in download mode, Windows asks to let
it make changes: it needs administrator rights to talk to the unit, and only
for that, in a helper of its own. Cancelled, it asks again once the unit is
reconnected. The app is not signed, so the first time Windows may say it
protected your PC: choose **More info → Run anyway**.

Microsoft Defender sometimes takes a new release for a threat and deletes
it, often under a name ending in `!ml` (a guess by its machine-learning
model). Each release is reported to Microsoft as a false alarm, which
usually clears it within a few days: then update Defender and download it
again. If you can't wait and the zip came from this repository's releases,
open **Windows Security → Virus & threat protection → Protection history**
and pick the M-Flasher entry:

- **Threat quarantined**: **Actions → Restore**. Defender finds it again: in
  the new **Threat found - action needed** entry choose **Allow on device**.
- **Threat blocked**: **Actions → Allow**, then download the zip again.

Please open an issue with the threat's name.

**macOS** (11 or newer, Apple silicon and Intel). Open
`M-Flasher-…-macos.dmg` and drag M-Flasher to Applications. The first time
macOS blocks it, as it is not signed with an Apple certificate: **System
Settings → Privacy & Security → Open Anyway**. ([Donations](../README.md#support)
would pay for the certificate.) When the app finds the unit:

- it asks for your password in the system's dialog: only an administrator may
  take a USB device from macOS's disk driver;
- macOS asks once whether M-Flasher may access files on a removable volume
  (that is the unit): choose **Allow**.

Start the app soon after connecting the unit: left with macOS's disk driver,
the unit may leave download mode after about half a minute.

**Linux** (x86-64 or ARM64, glibc 2.35 or newer). The packages set up
everything: the program, the udev rule that lets you reach the unit without
root, the SCSI generic driver, and a launcher in the app menu.

- Debian 12+, Ubuntu 22.04+, Linux Mint, Raspberry Pi OS (64-bit):
  `sudo apt install ./m-flasher_…_amd64.deb` (`_arm64.deb` for ARM64)
- Fedora, RHEL / AlmaLinux / Rocky 10, openSUSE Tumbleweed and Leap 16:
  `sudo dnf install ./m-flasher-….x86_64.rpm`, or `sudo zypper install
  ./m-flasher-….x86_64.rpm` (`.aarch64.rpm` for ARM64)

Connect the unit after installing (again, if it was connected), and start
M-Flasher from the app menu, or `m-flasher` in a terminal, as yourself: under
sudo the window cannot reach the desktop. The packages do not update
themselves: install the new one from each release.

On other distributions, use `m-flasher-…-linux-x86_64.tar.gz` (or
`-aarch64`; `uname -m` tells which) and follow its `README.txt`: install the
udev rule once, connect the unit, and run `./m-flasher`. M-Flasher talks to
the unit through the SCSI generic driver: run `sudo modprobe sg` if there is
no `/dev/sg*`. `m-flasher.png` is the icon, for a launcher of your own.

## Download mode

The unit's chip has a USB download mode built into its ROM, which works even
when the firmware does not. To enter it:

- with the unit running normally and connected: M-Flasher finds it on USB
  MIDI and offers **DOWNLOAD MODE**, which restarts it into download mode
  with a MIDI message (`m-flasher download-mode` on the command line). This
  works with M-VAVE's own firmware (FM-1 015, SMK-37 Pro and Elite 016) and
  Felucca, whichever bootloader the unit has;
- with m-bootloader: hold **REC** (SMK-37: **SEQ REC**) while switching the
  unit on;
- with Felucca, SLOOP or Snoop37 running: hold **OCT-** and **OCT+** for 5 s;
- a unit whose firmware is damaged often ends up there by itself.

Connect it directly with a USB **data** cable, not through a hub. In download
mode the unit's screen stays as it was, and nothing appears in Explorer or
Finder: the system sees an empty disk ("WL82 UBOOT1.00"). M-Flasher finds it
by itself, reads the whole flash and shows the model, the firmware and the
bootloader; the unit's own screen then shows what is going on.

A unit with the stock bootloader and a working stock firmware cannot be put
in download mode from its keys: use **DOWNLOAD MODE**. If the firmware does
not start, the USB_KEY dongle (a Raspberry Pi Pico) still reaches download
mode.

When you are done, unplug the unit and switch it off and on again, or run
`m-flasher restart`: it resets the unit from download mode, without touching
the flash, and waits for the firmware to show up on USB MIDI (the SMK-37's
stock firmware takes about half a minute).

## The actions

| Action | What it writes |
| --- | --- |
| **Back up the whole flash** | nothing: saves the 1 MiB flash image and a `.json` describing it |
| **Restore a backup** | the parts that differ; a backup of another unit keeps this unit's own factory data (calibration, Bluetooth address). With **Keep this unit's bootloader**, not the boot area (16 KiB): an older backup then leaves a newer m-bootloader in place |
| **Install firmware (.fwsc)** | the firmware from an M-VAVE package (or a custom one in the same format); optionally, from an official package, its stock bootloader. Nothing outside the package is erased |
| **Install m-bootloader** | the boot area only (16 KiB), the build for the identified model; of the unit's boot configuration, which it does not read, only the chip key that firmware installers need is kept |
| **Put back the stock bootloader** | the boot area only, all of it from an official package, the full configuration included |

On a unit with M-VAVE's stock bootloader, the window recommends installing
m-bootloader once it has read the flash, once per unit: with it, a unit whose
firmware doesn't start can be reflashed from its keys, with no extra hardware to
force download mode. **Yes** shows the
change for review, as any write; **No** leaves the unit as it is, and
**Flash bootloader** installs it later.

Use the official `.fwsc` files from M-VAVE's website as they are: no
conversion is needed. FM-1 **016** is supported, including its DX7 data file
and new settings and sequencer layout. An install writes the package's flash
image and nothing else: settings, Bluetooth pairings, presets and sequences stay
as they are, as with M-VAVE's updater and the custom firmwares' own installers.
Custom firmwares keep data in places of their own, some of it inside what stock
firmware declares as its settings area, so there is no erasing that would be
right for all of them. When switching between 015 and 016, or between firmwares
whose data layouts differ, the app warns. Restore a backup to return to the
earlier firmware with its data.

The **Fame MiniFM** is treated as an FM-1, and either's package installs on the
other: `MiniFM_016` and `FM-1_016` have the same chip key, data layout and boot
area. The app warns before such a cross-flash, because the unit then reports
itself as the other model and M-UPGRADE only accepts that model's packages. The
backup made before the write brings the original firmware back.

**Old and new FM-1s:** FM-1s sold from late 2026 have another flash chip, shown
under **Device info** as `0xB36014 (new)`; earlier ones show `0x856014 (old)`.
Firmware written before the new chip came may not work fully on it: some keep
settings only until the unit is switched off. Before installing a custom firmware
on a new FM-1, check that it supports the new chip.

**`BAD CONFIG` on the unit's screen:** m-bootloader before 1.3 rejects the boot
configuration of FM-1 016, which M-UPGRADE writes when it installs 016, and stops
at its menu on every start. **Boot app** in the menu still starts the firmware.
Installing the bundled m-bootloader fixes it. Over the bundled version, 1.2 and 1.3
start normally, including 1.2 from Melodee's or fm1-base's installer option. m-bootloader
2.0 kept less of the configuration, so 1.3 and older stop with `BAD CONFIG` over 2.0.

**`FAILED -5` on the unit's screen:** Melodee's **Return to official V15**, and
M-UPGRADE on an SMK-37 running Felucca-family firmware, stop there because the
unit's boot area differs from the package's, as it does with any m-bootloader.
The boot area and firmware stay as they were. Restore a backup with M-Flasher
instead, or install the firmware and put back the stock bootloader.

Backups go to `Documents/M-Flasher/backups` in your home folder; the
**Backups** link at the top of the window opens it.

## The flash map

The unit's 1 MiB flash is drawn as its 256 sectors of 4 KiB, coloured by what
they hold: bootloader, firmware, settings, Bluetooth pairings, factory
calibration, presets, sequences, sounds. When an action is chosen, the sectors
it would change are outlined; while writing, they light up as they are written
and verified. Hover over a sector to see its address and contents.

## Command line

The same executable is a command-line tool when given arguments:

```sh
m-flasher find                 # the units in download mode (and those running, on USB MIDI)
m-flasher download-mode        # switch a running unit to download mode over USB MIDI
m-flasher restart              # leave download mode: the unit resets and starts its firmware
m-flasher info                 # what is on the unit
m-flasher backup [DIR]
m-flasher restore BACKUP.bin
m-flasher firmware PACKAGE.fwsc [--with-bootloader]
m-flasher bootloader [--stock PACKAGE.fwsc | --file UBOOT.boot]
m-flasher run-ram IMAGE --addr 0x01C28000 [--call FC60]... [--read ADDR:LEN -o OUT]
```

Options: `--device PATH` (with more than one unit), `--board fm1|smk37` (when
the model is uncertain), `--backup-dir DIR`, `--yes`, `--keep-bootloader`
(restore: not the boot area), and `--restart` (restore, firmware and bootloader:
start the unit once written). Changes are shown first
and need a typed `yes`, or `--yes`.

- Windows: `M-Flasher.exe info`; Windows asks for administrator rights the
  same way, or run it from an administrator prompt.
- macOS: `/Applications/M-Flasher.app/Contents/MacOS/M-Flasher info`, from
  Terminal; it asks for the password the same way, or run it with `sudo`. Not
  over SSH: macOS asks about the removable volume only on the screen.
- Linux: `m-flasher info` (from the tarball: `./m-flasher info`); `man m-flasher` with the packages.

## Running your own program in RAM

`m-flasher run-ram` is for developers: it uploads a program of your own to the
chip's RAM through download mode, starts it, and then talks to it. It is how
m-bootloader's flash loader is started, without M-Flasher's own loader and
without any flash operation.

```sh
m-flasher run-ram prog.bin --addr 0x01C28000 --call FC60 --call FC61 \
                  --read 0x01C28000:4096 -o ram.bin
```

- `IMAGE` is a flat binary linked for `--addr`, with its entry at the first
  byte, built like the flash loader (m-bootloader's `docs/SPEC.md` §10 gives
  the contract). `--addr` is hex and must be from `0x01C20000` to below
  `0x01C7FD80`: the flash loader's two 32 KiB slots, then the app slot from
  `0x01C30000`. The image must end by `0x01C7FD80`, where the retained area
  starts. It is refused otherwise, and also when it would overwrite an
  M-Flasher loader that is running: use the other slot, or for an image over 32
  KiB, switch the unit off and on in download mode first.
- `--call OPCODE` (16-bit hex, repeatable) sends the 16-byte command (the
  opcode, then `FF`s) and prints the program's 16-byte answer in hex; the
  program is expected to echo the opcode in the first two bytes. Flash erase
  and write, memory write and jump (`FB00`, `FB01`, `FB04`, `FB06`, `FB08`) are
  never sent.
- `--read ADDR:LEN -o OUT` reads `LEN` bytes (decimal or `0x` hex, at most 16
  MiB) from `ADDR` (hex) into `OUT`, with `FD61` commands of at most 4096
  bytes: `FD 61`, the address (big-endian u32), the length (u16), then `FF`s.
  The program has to implement `FD61`, sending the bytes with the ROM's send
  callback.
- `--device PATH` as for the other commands.

A program doesn't have to go back to the ROM. It can move to its own stack as
soon as it starts, turn off interrupts and the watchdog, and never return,
which is how m-bootloader's RAM stage runs. The ROM's USB service stops then,
before it answers the jump, so M-Flasher says it can't confirm the start and
exits with success: go by what the unit does. `--call` and `--read` can't be
used with such a program, and asking for them gives an error.

This **runs arbitrary code on the chip**: only run programs you trust and
understand. It does not write to the flash itself, but a program of yours can
do anything the chip can. Nothing is kept: **switching the unit off and on
again returns it to normal**. It works whether or not M-Flasher's loader was
started before, and does not start it.

## Slow USB ports

A full read takes about 1.2 s and a firmware install about 10 s. Some USB
controllers are much slower with the unit (all ports of AMD's 600-series
chipset controller, for example: about 4.5 s for a read). The log shows the
read speed and suggests another port when it is slow; a port at the back,
next to the video outputs, is often on a faster controller.
