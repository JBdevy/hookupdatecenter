//! The operations, with their safety rules.
//!
//! Every session starts by reading the whole flash twice; the two reads must
//! match. Each change is planned against that image: a target image and the
//! address ranges the operation may touch. Only the 4 KiB sectors that differ
//! inside those ranges are erased and written, each run is read back and
//! compared (and rewritten once on a mismatch), and the image is saved as a
//! backup before the first write of a session.

use crate::boards::{Analysis, BOARDS, Board, BootKind, CHIP_KEY, FLASH_SIZE, flash_tested, flash_text};
use crate::formats::{
    AppStatus, BOOT_AREA, Package, SECTOR, app_files_status, crc32, app_table, bankcb_check, bootloader_identity,
    build_boot_area, build_short_boot_area, check_boot_area, config_cut_short, config_sys_clk, reads_config, stored_bootloader,
};
use crate::jl::{Flash, Show};
use crate::scsi::ScsiError;
use sha2::{Digest, Sha256};
use std::fmt;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone)]
pub enum Error {
    /// An operation the tool will not do, with the reason.
    Refused(String),
    Usb(ScsiError),
    Io(String),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Error::Refused(s) | Error::Io(s) => f.write_str(s),
            Error::Usb(e) => write!(f, "{e}"),
        }
    }
}

impl From<ScsiError> for Error {
    fn from(e: ScsiError) -> Self {
        Error::Usb(e)
    }
}

fn refuse<T>(s: impl Into<String>) -> Result<T, Error> {
    Err(Error::Refused(s.into()))
}

/// Refuses a package whose boot area would leave the unit unable to start if
/// written: custom firmware packages may carry only a stand-in there.
fn bootable_package_boot_area(pkg: &Package) -> Result<(), Error> {
    check_boot_area(&pkg.flash).map_err(|e| Error::Refused(format!(
        "the boot area of {} can't start the unit: {}. Custom firmware packages often carry only a stand-in \
         there, which their own installers never write. Install the firmware without the bootloader, and put back \
         the stock bootloader from an official M-VAVE package", pkg.identity, e.0)))
}

pub fn bundled_bootloader(board: &Board) -> Result<(&'static [u8], String), Error> {
    let boot: &'static [u8] = match board.key {
        "fm1" => include_bytes!("../data/bootloader-fm1.boot"),
        _ => include_bytes!("../data/bootloader-smk37.boot"),
    };
    match bootloader_identity(boot) {
        Some((tag, version)) if tag == board.tag => Ok((boot, version)),
        _ => refuse(format!("the bundled bootloader for the {} is damaged", board.name)),
    }
}

pub fn ranges_text(ranges: &[(usize, usize)]) -> String {
    ranges.iter().map(|(a, b)| format!("0x{a:05X}-0x{:05X}", b - 1)).collect::<Vec<_>>().join(", ")
}

/// A change: the target image, the ranges it may touch, the sectors that differ
/// and what the user should know before confirming.
#[derive(Clone)]
pub struct Plan {
    pub title: String,
    pub target: Vec<u8>,
    #[allow(dead_code)] // checked when planning; the tests read it
    pub allowed: Vec<(usize, usize)>,
    pub notes: Vec<String>,
    pub warnings: Vec<String>,
    pub sectors: Vec<usize>,
}

impl Plan {
    pub fn new(title: String, current: &[u8], target: Vec<u8>, allowed: Vec<(usize, usize)>,
               notes: Vec<String>, warnings: Vec<String>) -> Result<Plan, Error> {
        if target.len() != current.len() {
            return refuse("internal error: image size mismatch");
        }
        let mut sectors = vec![];
        for a in (0..current.len()).step_by(SECTOR) {
            if current[a..a + SECTOR] != target[a..a + SECTOR] {
                if !allowed.iter().any(|&(s, e)| s <= a && a + SECTOR <= e) {
                    return refuse(format!("internal error: the change at 0x{a:05X} is outside the allowed ranges ({})",
                                          ranges_text(&allowed)));
                }
                sectors.push(a);
            }
        }
        Ok(Plan { title, target, allowed, notes, warnings, sectors })
    }

    pub fn runs(&self) -> Vec<(usize, usize)> {
        let mut out: Vec<(usize, usize)> = vec![];
        for &a in &self.sectors {
            match out.last_mut() {
                Some(r) if r.1 == a => r.1 = a + SECTOR,
                _ => out.push((a, a + SECTOR)),
            }
        }
        out
    }

    pub fn describe(&self) -> String {
        let mut lines = vec![self.title.clone()];
        if self.sectors.is_empty() {
            lines.push("Nothing to write: the flash already holds this.".into());
        } else {
            lines.push(format!("Writes {} sectors ({} KiB): {}", self.sectors.len(), self.sectors.len() * 4,
                               ranges_text(&self.runs())));
        }
        lines.extend(self.notes.iter().cloned());
        lines.join("\n")
    }
}

/// Progress of a write: what is happening and the address done up to.
pub enum Event {
    Backup,
    Erase(usize),
    Write(usize),
    Verify(usize),
}

/// A connected unit: its flash image as read, and the operations.
pub struct Session<F: Flash> {
    pub dev: F,
    pub flash: Vec<u8>,
    pub analysis: Analysis,
    pub backup_dir: PathBuf,
    pub backup_path: Option<PathBuf>,
    pub board_override: Option<&'static Board>,
    /// The flash chip's factory-unique ID (our loader only): which unit this is.
    pub unit_id: Option<String>,
    /// The unit's own display is showing our screens.
    pub display: bool,
}

// the unit's display: colours (RGB565) and the screens' text (its font has
// A-Z, 0-9 and - . / : < > + ? only)
const MINT: u16 = 0x7F57;
const LAV: u16 = 0xB51C;
const AMBER: u16 = 0xFDA0;
const WHITE: u16 = 0xFFFF;

fn screen_text(s: &str) -> String {
    s.to_uppercase().chars().map(|c| if c.is_ascii_alphanumeric() || " -./:<>+?".contains(c) { c } else { ' ' }).collect()
}

impl<F: Flash> Session<F> {
    pub fn open(mut dev: F, backup_dir: PathBuf, log: &mut dyn FnMut(String),
                progress: &mut dyn FnMut(usize, usize)) -> Result<Self, Error> {
        if dev.chip_key() != CHIP_KEY {
            log(format!("Note: chip key 0x{:04X} (0x{CHIP_KEY:04X} expected)", dev.chip_key()));
        }
        log(format!("Flash chip {}", flash_text(dev.flash_id())));
        log("Reading the flash".into());
        let started = std::time::Instant::now();
        let a = dev.read(0, FLASH_SIZE, &mut |d| progress(d, FLASH_SIZE))?;
        let rate = FLASH_SIZE as f64 / 1024.0 / started.elapsed().as_secs_f64().max(1e-3);
        log(format!("Read in {:.1} s ({rate:.0} KB/s)", started.elapsed().as_secs_f64()));
        if rate < 400.0 {
            // Some USB controllers (seen: AMD's chipset one) collect only a few of
            // the unit's 64-byte packets per millisecond; others take 3-4 times more.
            log("Tip: this USB port is slow for the unit. A port on another USB controller can be \
                 3-4 times faster, often a rear one next to the video outputs (on the CPU's own controller)."
                .into());
        }
        // The read is checked against the loader's CRC32 of the whole flash,
        // computed on the chip in under a second (a loader without it: read again).
        match dev.crc32(0, FLASH_SIZE)? {
            Some(c) if c == crc32(&a) => log("Checked: the chip's CRC32 of the flash matches the read".into()),
            check => {
                if check.is_some() {
                    log("The chip's CRC32 does not match the read: reading it again".into());
                } else {
                    log("Reading it again to compare".into());
                }
                let b = dev.read(0, FLASH_SIZE, &mut |d| progress(d, FLASH_SIZE))?;
                if a != b || check.is_some_and(|c| c != crc32(&b)) {
                    return refuse("two reads of the flash differ: the USB connection is unreliable. Nothing was written. \
                                   Try another cable or port, without a hub.");
                }
            }
        }
        let analysis = Analysis::new(&a, Some(dev.flash_id()), dev.chip_key());
        let unit_id = dev.unique_id();
        Ok(Session { dev, flash: a, analysis, backup_dir, backup_path: None, board_override: None, unit_id, display: false })
    }

    pub fn board(&self) -> Option<&'static Board> {
        self.board_override.or(self.analysis.board)
    }

    fn need_board(&self) -> Result<&'static Board, Error> {
        self.board().ok_or_else(|| Error::Refused("the model could not be identified: choose it first".into()))
    }

    /// Whether to recommend m-bootloader, and the key that opens its recovery menu:
    /// the unit has the stock bootloader, a model known for certain, and a flash
    /// chip m-bootloader runs on.
    pub fn bootloader_suggestion(&self) -> Option<&'static str> {
        let board = self.board()?;
        let certain = self.analysis.certain || self.board_override.is_some();
        (self.analysis.bootloader == BootKind::Stock && certain && flash_tested(self.dev.flash_id())).then_some(board.menu_key)
    }

    /// (label, value) pairs for display and for the backup's .json.
    pub fn info(&self) -> Vec<(&'static str, String)> {
        vec![
            ("model", self.board_override.map(|b| b.name.to_string()).unwrap_or_else(|| self.analysis.model_text())),
            ("bootloader", self.analysis.bootloader_text.clone()),
            ("firmware", self.analysis.firmware_text.clone()),
            ("app", self.analysis.app_status.text().to_string()),
            ("chip key", format!("0x{:04X}", self.dev.chip_key())),
            ("flash", format!("0x{:06X}", self.dev.flash_id())),
            ("unit id", self.unit_id.clone().unwrap_or_else(|| "–".into())),
            ("loader", self.dev.loader()),
        ]
    }

    /// Show our screens on the unit's own display, if the loader can and the
    /// model (which says where the display is wired) is known.
    pub fn show_on_unit(&mut self) {
        let Some(board) = self.board() else { return };
        if self.board_override.is_none() && !self.analysis.certain {
            return;
        }
        self.dev.show(Show::On(if board.key == "fm1" { 1 } else { 2 }));
        self.display = true;
        let firmware = screen_text(&self.analysis.firmware_text);
        self.screen(&[(1, " M-FLASHER", MINT), (3, " CONNECTED", WHITE), (5, &format!(" {}", screen_text(board.name)), LAV),
                      (6, &format!(" {firmware}"), LAV), (12, " READY", MINT)]);
    }

    fn screen(&mut self, lines: &[(u8, &str, u16)]) {
        if !self.display {
            return;
        }
        for &(row, text, color) in lines {
            self.dev.show(Show::Text(row, text, color));
        }
    }

    pub fn save_backup(&mut self, dir: Option<&Path>) -> Result<PathBuf, Error> {
        let dir = dir.map(Path::to_path_buf).unwrap_or_else(|| self.backup_dir.clone());
        create_dirs(&dir).map_err(|e| Error::Io(format!("cannot create {}: {e}", dir.display())))?;
        let stamp = chrono::Local::now().format("%Y%m%d-%H%M%S").to_string();
        let model = self.board().map(|b| b.key).unwrap_or("unknown");
        // two backups in the same second: the second gets -2 (and so on). The
        // name is taken by creating the file, so that another M-Flasher saving
        // at the same moment gets the next one, and neither writes over the other's.
        let (path, file) = (1..)
            .map(|i| dir.join(if i == 1 { format!("{model}-{stamp}.bin") } else { format!("{model}-{stamp}-{i}.bin") }))
            .filter(|p| !p.with_extension("json").exists())
            .find_map(|p| match create_new(&p) {
                Ok(f) => Some(Ok((p, f))),
                Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => None,
                Err(e) => Some(Err(Error::Io(format!("cannot write {}: {e}", p.display())))),
            })
            .unwrap()?;
        write_synced(&path, file, &self.flash)?;
        let mut json = String::from("{\n");
        for (k, v) in self.info() {
            json += &format!("  \"{k}\": \"{}\",\n", v.replace('\\', "\\\\").replace('"', "\\\""));
        }
        let sha: String = Sha256::digest(&self.flash).iter().map(|b| format!("{b:02x}")).collect();
        json += &format!("  \"sha256\": \"{sha}\",\n");
        json += &format!("  \"saved\": \"{stamp}\",\n  \"tool\": \"m-flasher {}\"\n}}\n", env!("CARGO_PKG_VERSION"));
        let json_path = path.with_extension("json");
        let file = create_new(&json_path).map_err(|e| Error::Io(format!("cannot write {}: {e}", json_path.display())))?;
        write_synced(&json_path, file, json.as_bytes())?;
        // the two names are on the disk too, not only what the files hold
        sync_dir(&dir).map_err(|e| Error::Io(format!("cannot save the backup in {}: {e}", dir.display())))?;
        give_to_sudo_user(&path);
        give_to_sudo_user(&path.with_extension("json"));
        self.backup_path = Some(path.clone());
        Ok(path)
    }

    /// backup_unit: the unit ID saved with the backup, if any. When both it and
    /// this unit's are known, they decide whether it is this unit's backup.
    /// keep_bootloader: the boot area is not restored (a newer bootloader kept).
    pub fn plan_restore(&self, data: &[u8], backup_unit: Option<&str>, keep_bootloader: bool) -> Result<Plan, Error> {
        if data.len() != FLASH_SIZE {
            return refuse(format!("not a full backup: {} bytes, {FLASH_SIZE} expected", data.len()));
        }
        let backup = Analysis::new(data, None, CHIP_KEY);
        let board = self.board();
        if let (Some(a), Some(b)) = (backup.board, board) {
            if a.key != b.key {
                return refuse(format!("this backup is from a {}, the connected unit is a {}", a.name, b.name));
            }
        }
        let factory: &[(usize, usize)] = board.map(|b| b.factory).unwrap_or(&[(0xFF000, FLASH_SIZE)]);
        let same_unit = match (backup_unit, self.unit_id.as_deref()) {
            (Some(b), Some(u)) => b == u,
            _ => factory.iter().all(|&(a, b)| data[a..b] == self.flash[a..b] || self.flash[a..b].iter().all(|&x| x == 0xFF)),
        };
        let (mut notes, mut warnings) = (vec![], vec![]);
        let allowed = if same_unit {
            if !keep_bootloader {
                notes.push("The whole flash is restored, the bootloader included.".into());
            }
            for &(a, b) in factory {
                if data[a..b] != self.flash[a..b] {
                    warnings.push(format!("This unit's factory data at {} is blank; the backup's is restored. \
                                           Use only a backup of this unit.", ranges_text(&[(a, b)])));
                }
            }
            vec![(0, FLASH_SIZE)]
        } else {
            let mut fs = factory.to_vec();
            fs.sort();
            let (mut allowed, mut at) = (vec![], 0);
            for (a, b) in fs {
                if a > at {
                    allowed.push((at, a));
                }
                at = b;
            }
            if at < FLASH_SIZE {
                allowed.push((at, FLASH_SIZE));
            }
            warnings.push(format!("This backup {} another unit: its factory data ({}: calibration, Bluetooth address) is \
                                   not restored, this unit keeps its own.",
                                  if backup_unit.is_some() && self.unit_id.is_some() { "is from" } else { "seems to come from" },
                                  ranges_text(factory)));
            allowed
        };
        let allowed: Vec<(usize, usize)> = if keep_bootloader {
            notes.push(format!("This unit keeps its bootloader ({}): the boot area ({}) is not restored.",
                               self.analysis.bootloader_text, ranges_text(&[(0, BOOT_AREA)])));
            if matches!(self.analysis.bootloader, BootKind::Damaged | BootKind::Unknown) {
                warnings.push(format!("This unit's bootloader is {}: kept, the unit may not start. Restore the \
                                       backup's with it.", self.analysis.bootloader_text));
            }
            allowed.into_iter().filter_map(|(a, b)| (a.max(BOOT_AREA) < b).then_some((a.max(BOOT_AREA), b))).collect()
        } else {
            allowed
        };
        let mut target = self.flash.clone();
        for &(a, b) in &allowed {
            target[a..b].copy_from_slice(&data[a..b]);
        }
        Plan::new("Restore a backup".into(), &self.flash, target, allowed, notes, warnings)
    }

    pub fn plan_firmware(&self, raw: &[u8], with_bootloader: bool) -> Result<Plan, Error> {
        let pkg = Package::parse(raw).map_err(|e| Error::Refused(e.0))?;
        let board = self.need_board()?;
        if !board.models.contains(&pkg.model()) {
            return refuse(format!("this package is for the {}, the connected unit is a {}", pkg.model(), board.name));
        }
        if pkg.flash.len() > FLASH_SIZE {
            return refuse("the package is larger than the flash");
        }
        let key = self.dev.chip_key();
        let mut padded = pkg.flash.clone();
        padded.resize(FLASH_SIZE, 0xFF);
        if app_files_status(&padded, key) != AppStatus::Ok {
            return refuse(format!("the package's firmware does not decrypt with this unit's chip key (0x{key:04X}): \
                                   writing it would not start"));
        }
        let (mut notes, mut warnings) = (vec![], vec![]);
        if let Some(m) = &self.analysis.model_name {
            if m != "SMK-37+VA" && m != pkg.model() {
                warnings.push(format!("The unit runs {m} firmware; this package is for the {}. The unit will then \
                                       report itself as that model, and M-UPGRADE will only take that model's \
                                       packages.", pkg.model()));
            }
        }
        let regions = |img: &[u8]| -> Vec<(String, u32, u32)> {
            let mut v: Vec<_> = app_table(img, key).into_iter().filter(|e| e.attr == 0x12 || e.attr == 0x92)
                .map(|e| (e.name, e.addr, e.len)).collect();
            v.sort();
            v
        };
        let old = regions(&self.flash);
        if !old.is_empty() && old != regions(&padded) {
            warnings.push(format!("The installed firmware ({}) keeps its data in other places than {}; what it leaves \
                                   behind can confuse the new firmware (wrong presets, no sound). To go back to a \
                                   firmware cleanly, restore a backup made while it was installed.",
                                  self.analysis.firmware_text, pkg.identity));
        }
        if with_bootloader {
            bootable_package_boot_area(&pkg)?;
        }
        let start = if with_bootloader { 0 } else { BOOT_AREA };
        let end = pkg.flash.len();
        let mut target = self.flash.clone();
        target[start..end].copy_from_slice(&pkg.flash[start..end]);
        let allowed = vec![(start, end)];
        notes.push(format!("Installs {} ({}).", pkg.identity, ranges_text(&allowed)));
        if with_bootloader {
            notes.push("Also puts back the package's stock bootloader: its whole boot area.".into());
        }
        Plan::new(format!("Install firmware {}", pkg.identity), &self.flash, target, allowed, notes, warnings)
    }

    /// Our bundled bootloader (`boot` None), a given uboot.boot, or the stock one
    /// from a package's boot area.
    pub fn plan_bootloader(&self, boot: Option<&[u8]>, package: Option<&[u8]>) -> Result<Plan, Error> {
        let board = self.need_board()?;
        // the package's whole boot area, with the stock bootloader the
        // configuration it reads: the unit's may have been cut short
        let mut stock_area = None;
        let (boot, title): (Vec<u8>, String) = if let Some(raw) = package {
            let pkg = Package::parse(raw).map_err(|e| Error::Refused(e.0))?;
            if !board.models.contains(&pkg.model()) {
                return refuse(format!("this package is for the {}, the connected unit is a {}", pkg.model(), board.name));
            }
            bootable_package_boot_area(&pkg)?;
            let b = stored_bootloader(&pkg.flash).ok_or_else(|| Error::Refused("the package has no readable bootloader".into()))?;
            // its boot area replaces the unit's, chip-key record included
            let key = self.dev.chip_key();
            let mut padded = pkg.flash.clone();
            padded.resize(FLASH_SIZE, 0xFF);
            if app_files_status(&padded, key) != AppStatus::Ok {
                return refuse(format!("the package does not match this unit's chip key (0x{key:04X}): its boot area would not \
                                       start the unit's firmware"));
            }
            stock_area = Some(pkg.flash[..BOOT_AREA].to_vec());
            (b, format!("Put back the stock bootloader (from {})", pkg.identity))
        } else if let Some(b) = boot {
            bankcb_check(b).map_err(|e| Error::Refused(e.0))?;
            let ident = bootloader_identity(b);
            if let Some((tag, _)) = &ident {
                if tag != board.tag {
                    return refuse(format!("this bootloader is built for \"{tag}\", the unit is a {}", board.name));
                }
            }
            let v = ident.map(|i| i.1).unwrap_or_else(|| "unknown".into());
            (b.to_vec(), format!("Install the bootloader {v} for the {}", board.name))
        } else {
            let (b, v) = bundled_bootloader(board)?;
            (b.to_vec(), format!("Install m-bootloader {v} for the {}", board.name))
        };
        let full = reads_config(&boot);
        let (area, note) = match stock_area {
            Some(area) => (area, "Only the boot area (0x00000-0x03FFF) is written, all of it from the package."),
            None if full => (build_boot_area(&self.flash, &boot)
                .map_err(|e| Error::Refused(format!("{}; install firmware with its bootloader instead", e.0)))?,
                "Only the boot area (0x00000-0x03FFF) is written; the unit's own configuration in it is kept."),
            None => (build_short_boot_area(&self.flash, &boot)
                .map_err(|e| Error::Refused(format!("{}; install firmware with its bootloader instead", e.0)))?,
                "Only the boot area (0x00000-0x03FFF) is written. This bootloader does not read the unit's configuration, \
                 so of that only the chip key is kept, with the settings older versions need."),
        };
        let mut target = area;
        target.extend_from_slice(&self.flash[BOOT_AREA..]);
        // the stock bootloader is what the unit came with
        let id = self.dev.flash_id();
        let mut warnings = vec![];
        if package.is_none() && !flash_tested(id) {
            warnings.push(format!("This unit's flash chip (0x{id:06X}) is not one m-bootloader is known to run on. \
                                   Install it at your own risk."));
        }
        if package.is_none() && full {
            let hz = config_sys_clk(&self.flash);
            match bootloader_identity(&boot) {
                Some((_, v)) => {
                    // before 1.3 only 360 MHz is taken, and FM-1 016's configuration says
                    // 320; 2.0's short configuration, without settings, is not taken either
                    let before_1_3 = !v.starts_with(|c: char| c.is_ascii_digit())
                        || ["1.0", "1.1", "1.2"].iter().any(|o| v.starts_with(o));
                    if hz.is_none_or(|hz| before_1_3 && hz != 360_000_000) {
                        warnings.push(format!("This bootloader ({v}) rejects this unit's boot configuration: it would stop at \
                                               its menu with BAD CONFIG on every start. Install m-bootloader 1.4 or newer instead."));
                    }
                }
                None if config_cut_short(&self.flash) => warnings.push(
                    "This unit's boot configuration has been cut short, and this bootloader may need all of it: the unit may \
                     not start. To put back the stock bootloader, use its official package instead.".into()),
                None => {}
            }
        }
        Plan::new(title, &self.flash, target, vec![(0, BOOT_AREA)], vec![note.into()], warnings)
    }

    pub fn apply(&mut self, plan: &Plan, event: &mut dyn FnMut(Event), log: &mut dyn FnMut(String)) -> Result<(), Error> {
        if plan.sectors.is_empty() {
            log("Nothing to write".into());
            return Ok(());
        }
        if self.backup_path.is_none() {
            event(Event::Backup);
            let p = self.save_backup(None)?;
            log(format!("Backup saved: {}", p.display()));
        }
        let what = if plan.title.starts_with("Install firmware") { " INSTALL FIRMWARE" }
            else if plan.title.starts_with("Restore") { " RESTORE BACKUP" } else { " BOOTLOADER" };
        let total = plan.sectors.len();
        self.screen(&[(3, what, WHITE), (5, " WRITING", WHITE), (6, "", WHITE), (12, " DO NOT SWITCH OFF", AMBER)]);
        let (mut done, mut shown) = (0usize, usize::MAX);
        for (a, b) in plan.runs() {
            let want = &plan.target[a..b];
            let mut attempt = 1;
            loop {
                log(format!("Writing 0x{a:05X}-0x{:05X}{}", b - 1, if attempt == 2 { " (again)" } else { "" }));
                event(Event::Erase(a));
                self.dev.erase(a, b - a)?;
                // sector by sector, so that the unit's display can follow
                for s in (a..b).step_by(SECTOR) {
                    self.dev.program(s, &plan.target[s..s + SECTOR], &mut |n| event(Event::Write(s + n)))?;
                    let pct = 100 * (done + (s + SECTOR - a) / SECTOR) / total;
                    if self.display && pct / 2 != shown / 2 {
                        shown = pct;
                        self.dev.show(Show::Bar(pct as u8, MINT));
                        let t = format!(" {pct:3}%  {}/{total}", done + (s + SECTOR - a) / SECTOR);
                        self.dev.show(Show::Text(13, &t, MINT));
                    }
                }
                // verify: the chip's CRC32 of what is now there (ours), or read it all back
                let ok = match self.dev.crc32(a, b - a)? {
                    Some(c) => {
                        event(Event::Verify(b));
                        c == crc32(want)
                    }
                    None => self.dev.read(a, b - a, &mut |n| event(Event::Verify(a + n)))? == want,
                };
                if ok {
                    break;
                }
                let got = self.dev.read(a, b - a, &mut |_| {})?;
                if attempt == 2 {
                    self.flash[a..b].copy_from_slice(&got);
                    return refuse(format!("0x{a:05X}-0x{:05X} does not read back as written. Do not switch the unit off: \
                                           try again, with another cable or port. Your backup: {}",
                                          b - 1, self.backup_path.as_ref().map(|p| p.display().to_string()).unwrap_or_default()));
                }
                attempt += 1;
            }
            self.flash[a..b].copy_from_slice(want);
            done += (b - a) / SECTOR;
        }
        self.analysis = Analysis::new(&self.flash, Some(self.dev.flash_id()), self.dev.chip_key());
        if self.display {
            self.dev.show(Show::Bar(100, MINT));
        }
        self.screen(&[(5, " DONE - VERIFIED", MINT), (13, &format!(" {total} SECTORS OK"), MINT), (12, " SWITCH OFF AND ON", WHITE)]);
        log(if self.dev.loader().starts_with("M-Flasher") {
            "Done: everything written is verified (the chip's CRC32 matches)".into()
        } else {
            "Done: everything written was read back and matches".into()
        });
        Ok(())
    }
}

/// A new file: never one that exists.
fn create_new(path: &Path) -> std::io::Result<std::fs::File> {
    std::fs::OpenOptions::new().write(true).create_new(true).open(path)
}

/// Writes a file and has the system put it on the disk before returning: a
/// backup must survive the computer losing power during the write it precedes.
fn write_synced(path: &Path, mut f: std::fs::File, data: &[u8]) -> Result<(), Error> {
    use std::io::Write;
    let io = |e: std::io::Error| Error::Io(format!("cannot write {}: {e}", path.display()));
    f.write_all(data).map_err(io)?;
    f.sync_all().map_err(io)
}

/// Has the system put a folder's list of names on the disk: a synced file
/// whose name is not there yet is lost with the power all the same. (Windows
/// keeps names with the files, and does not let a folder be opened for this.)
/// A file system that has no such thing (some network and FUSE ones say so)
/// is not an error: there the file's own sync is all there is. Any other
/// failure is, before anything is erased.
fn sync_dir(_dir: &Path) -> std::io::Result<()> {
    #[cfg(unix)]
    if let Err(e) = std::fs::File::open(_dir).and_then(|d| d.sync_all()) {
        use std::io::ErrorKind::{InvalidInput, Unsupported};
        if !matches!(e.kind(), InvalidInput | Unsupported) {
            return Err(e);
        }
    }
    Ok(())
}

/// The text of `key` in a backup's .json, however the file is spaced.
fn json_text<'a>(json: &'a str, key: &str) -> Option<&'a str> {
    let quoted = format!("\"{key}\"");
    let rest = json[json.find(&quoted)? + quoted.len()..].trim_start().strip_prefix(':')?.trim_start().strip_prefix('"')?;
    rest.split('"').next()
}

/// Checks a backup file against the SHA-256 saved with it in its .json. No
/// .json, or one without a checksum (a backup from elsewhere): nothing to
/// check. One that can't be read, or whose checksum isn't one, is refused:
/// the check must not quietly not happen.
pub fn check_backup_file(backup: &Path, data: &[u8]) -> Result<(), Error> {
    let json_path = backup.with_extension("json");
    let json = match std::fs::read_to_string(&json_path) {
        Ok(j) => j,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(e) => return refuse(format!("cannot read {} to check the backup against it: {e}", json_path.display())),
    };
    if !json.contains("\"sha256\"") {
        return Ok(());
    }
    let saved = json_text(&json, "sha256").filter(|s| s.len() == 64 && s.chars().all(|c| c.is_ascii_hexdigit()));
    let Some(saved) = saved else {
        return refuse(format!("the SHA-256 in {} is not readable, so the backup can't be checked against it. If you \
                               trust the backup, remove that .json file.", json_path.display()));
    };
    let sha: String = Sha256::digest(data).iter().map(|b| format!("{b:02x}")).collect();
    if !sha.eq_ignore_ascii_case(saved) {
        return refuse(format!(
            "{} is not the file that was saved: its SHA-256 differs from the one in {}. The backup is damaged or was \
             changed. Use another backup; if you changed it on purpose, remove that .json file.",
            backup.display(), json_path.display()));
    }
    Ok(())
}

/// The unit ID saved in a backup's .json, if any.
pub fn backup_unit_id(backup: &Path) -> Option<String> {
    let json = std::fs::read_to_string(backup.with_extension("json")).ok()?;
    let id = json_text(&json, "unit id")?;
    (id.len() == 16 && id.chars().all(|c| c.is_ascii_hexdigit())).then(|| id.to_string())
}

/// create_dir_all, the new folders given to the user who ran sudo.
pub fn create_dirs(dir: &Path) -> std::io::Result<()> {
    let new: Vec<PathBuf> = dir.ancestors().take_while(|d| !d.as_os_str().is_empty() && !d.exists())
        .map(Path::to_path_buf).collect();
    std::fs::create_dir_all(dir)?;
    new.iter().for_each(|d| give_to_sudo_user(d));
    // the new folders' names, in the folders they were made in
    for d in new.iter().filter_map(|d| d.parent()).filter(|p| !p.as_os_str().is_empty()) {
        sync_dir(d)?;
    }
    Ok(())
}

/// Run with sudo (macOS needs it), the files the app creates still belong to
/// the user who ran it.
fn give_to_sudo_user(_path: &Path) {
    #[cfg(unix)]
    {
        let id = |v| std::env::var(v).ok().and_then(|s| s.parse::<u32>().ok());
        if let (Some(uid), Some(gid)) = (id("SUDO_UID"), id("SUDO_GID")) {
            let _ = std::os::unix::fs::chown(_path, Some(uid), Some(gid));
        }
    }
}

/// The model by its key (for the command line's --board).
pub fn board_from_key(key: &str) -> Option<&'static Board> {
    BOARDS.iter().copied().find(|b| b.key == key)
}
